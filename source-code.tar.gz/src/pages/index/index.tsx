import { View, Text, ScrollView } from '@tarojs/components'
import Taro, { useDidShow } from '@tarojs/taro'
import { useState } from 'react'
import type { FC } from 'react'
import { Network } from '@/network'
import './index.css'

type TabType = 'realtime' | 'heartbeat' | 'dragonTiger' | 'trendLeader' | 'newsCatalyst' | 'hotReview'

// 行业板块数据结构
interface TopStock {
  '代码': string
  '名称': string
  '最新价': number
  '涨跌幅': number
  '涨速': number
}

interface IndustryBoard {
  board_name: string
  board_code: string
  change_percent: number
  change_speed: number
  latest_price: number
  turnover_rate: number
  amount: number
  up_count: number
  down_count: number
  top_stocks: TopStock[]
}

// 涨停股数据结构
interface LimitUpStock {
  code: string
  name: string
  price: number
  change_percent: number
  limit_up_time: string
  first_limit_up_time: string
  open_count: number
  turnover_rate: number
  amount: number
  reason: string
}

// 龙虎榜数据结构
interface DragonTigerStock {
  code: string
  name: string
  price: number
  change_percent: number
  turnover_rate: number
  amount: number
  net_buy: number
  buy_reason: string
  sell_reason: string
  famous_buyers: string[]
  famous_sellers: string[]
  buy_amount: number
  sell_amount: number
  date: string
}

// 趋势龙头数据结构
interface TrendLeaderStock {
  code: string
  name: string
  price: number
  change_percent: number
  days_rising: number
  total_change: number
  industry: string
  market_cap: number
  turnover_rate: number
  strength_score: number
  trend_stage: string
  support_level: number
  resistance_level: number
}

// 新闻催化数据结构
interface NewsCatalyst {
  type: string
  title: string
  content: string
  stocks: string[]
  stock_codes: string[]
  importance: 'high' | 'medium' | 'low'
  source: string
  publish_time: string
  suggestion: string
}

// 热点复盘数据结构
interface HotStock {
  code: string
  name: string
  price: number
  change_percent: number
  heat_score: number  // 热度分数 0-100
  heat_rank: number   // 热度排名
  heat_sources: string[]  // 热度来源
  reasons: string[]   // 热门原因
  suggestion: string  // 投资建议
  risk_level: 'high' | 'medium' | 'low'  // 风险等级
  market_sentiment: string  // 市场情绪
  related_concepts: string[]  // 相关概念
}

interface HotReviewData {
  date: string
  summary: string  // 市场概述
  hot_stocks: HotStock[]  // 热门股票
  top_news: { title: string; source: string; time: string }[]  // 头条新闻
  analysis: string  // AI分析
}

const IndexPage: FC = () => {
  const [activeTab, setActiveTab] = useState<TabType>('realtime')
  const [industryData, setIndustryData] = useState<IndustryBoard[]>([])
  const [limitUpStocks, setLimitUpStocks] = useState<LimitUpStock[]>([])
  const [dragonTigerData, setDragonTigerData] = useState<DragonTigerStock[]>([])
  const [trendLeaderData, setTrendLeaderData] = useState<TrendLeaderStock[]>([])
  const [newsCatalystData, setNewsCatalystData] = useState<NewsCatalyst[]>([])
  const [hotReviewData, setHotReviewData] = useState<HotReviewData | null>(null)
  const [loading, setLoading] = useState(false)
  const [isLoggedIn, setIsLoggedIn] = useState(false)
  const [isAdmin, setIsAdmin] = useState(false)
  const [expandedBoard, setExpandedBoard] = useState<string | null>(null)
  
  // 数据来源和更新时间
  const [hotReviewSource, setHotReviewSource] = useState<string>('')
  const [hotReviewUpdateTime, setHotReviewUpdateTime] = useState<string>('')
  const [industrySource, setIndustrySource] = useState<string>('')
  const [industryUpdateTime, setIndustryUpdateTime] = useState<string>('')
  const [limitUpSource, setLimitUpSource] = useState<string>('')
  const [limitUpUpdateTime, setLimitUpUpdateTime] = useState<string>('')
  const [dragonTigerSource, setDragonTigerSource] = useState<string>('')
  const [dragonTigerUpdateTime, setDragonTigerUpdateTime] = useState<string>('')
  const [trendLeaderSource, setTrendLeaderSource] = useState<string>('')
  const [trendLeaderUpdateTime, setTrendLeaderUpdateTime] = useState<string>('')
  const [newsCatalystSource, setNewsCatalystSource] = useState<string>('')
  const [newsCatalystUpdateTime, setNewsCatalystUpdateTime] = useState<string>('')

  useDidShow(() => {
    const loggedIn = Taro.getStorageSync('isLoggedIn')
    const userRole = Taro.getStorageSync('userRole')
    if (!loggedIn) {
      Taro.redirectTo({ url: '/pages/login/index' })
    } else {
      setIsLoggedIn(true)
      setIsAdmin(userRole === 'admin')
      loadData()
    }
  })

  const loadData = async () => {
    setLoading(true)
    try {
      await Promise.all([
        loadIndustryData(),
        loadLimitUpStocks(),
        loadDragonTigerData(),
        loadTrendLeaderData(),
        loadNewsCatalystData(),
        loadHotReviewData()
      ])
    } catch (error) {
      console.error('加载数据错误:', error)
    } finally {
      setLoading(false)
    }
  }

  const loadIndustryData = async () => {
    try {
      const res = await Network.request({
        url: '/api/stock/industry',
        method: 'GET'
      })
      console.log('行业数据:', res.data)
      if (res.data.code === 200 && res.data.data) {
        setIndustryData(res.data.data)
        setIndustrySource(res.data.source || 'unknown')
        setIndustryUpdateTime(res.data.updateTime || '')
      }
    } catch (error) {
      console.error('加载行业数据失败:', error)
    }
  }

  const loadLimitUpStocks = async () => {
    try {
      const res = await Network.request({
        url: '/api/stock/limit-up',
        method: 'GET'
      })
      console.log('涨停数据:', res.data)
      if (res.data.code === 200 && res.data.data) {
        setLimitUpStocks(res.data.data)
        setLimitUpSource(res.data.source || 'unknown')
        setLimitUpUpdateTime(res.data.updateTime || '')
      }
    } catch (error) {
      console.error('加载涨停数据失败:', error)
    }
  }

  const loadDragonTigerData = async () => {
    try {
      const res = await Network.request({
        url: '/api/stock/dragon-tiger',
        method: 'GET'
      })
      console.log('龙虎榜数据:', res.data)
      if (res.data.code === 200 && res.data.data) {
        setDragonTigerData(res.data.data)
        setDragonTigerSource(res.data.source || 'unknown')
        setDragonTigerUpdateTime(res.data.updateTime || '')
      }
    } catch (error) {
      console.error('加载龙虎榜数据失败:', error)
    }
  }

  const loadTrendLeaderData = async () => {
    try {
      const res = await Network.request({
        url: '/api/stock/trend-leader',
        method: 'GET'
      })
      console.log('趋势龙头数据:', res.data)
      if (res.data.code === 200 && res.data.data) {
        setTrendLeaderData(res.data.data)
        setTrendLeaderSource(res.data.source || 'unknown')
        setTrendLeaderUpdateTime(res.data.updateTime || '')
      }
    } catch (error) {
      console.error('加载趋势龙头数据失败:', error)
    }
  }

  const loadNewsCatalystData = async () => {
    try {
      const res = await Network.request({
        url: '/api/stock/news-catalyst',
        method: 'GET'
      })
      console.log('新闻催化数据:', res.data)
      if (res.data.code === 200 && res.data.data) {
        setNewsCatalystData(res.data.data)
        setNewsCatalystSource(res.data.source || 'unknown')
        setNewsCatalystUpdateTime(res.data.updateTime || '')
      }
    } catch (error) {
      console.error('加载新闻催化数据失败:', error)
    }
  }

  const loadHotReviewData = async () => {
    try {
      const res = await Network.request({
        url: '/api/stock/hot-review',
        method: 'GET'
      })
      console.log('热点复盘数据:', res.data)
      if (res.data.code === 200 && res.data.data) {
        setHotReviewData(res.data.data)
        setHotReviewSource(res.data.source || 'unknown')
        setHotReviewUpdateTime(res.data.updateTime || '')
      }
    } catch (error) {
      console.error('加载热点复盘数据失败:', error)
    }
  }

  const formatTime = (timeStr: string): string => {
    if (!timeStr) return ''
    const date = new Date(timeStr)
    return `${date.getHours().toString().padStart(2, '0')}:${date.getMinutes().toString().padStart(2, '0')}:${date.getSeconds().toString().padStart(2, '0')}`
  }

  const getSourceLabel = (source: string): string => {
    switch (source) {
      case 'akshare': return '实时数据'
      case 'cache': return '缓存数据'
      case 'mock': return '演示数据'
      default: return '未知来源'
    }
  }

  const getSourceColor = (source: string): string => {
    switch (source) {
      case 'akshare': return '#10B981'  // 绿色 - 实时
      case 'cache': return '#F59E0B'    // 橙色 - 缓存
      case 'mock': return '#64748B'     // 灰色 - 演示
      default: return '#64748B'
    }
  }

  const formatAmount = (amount: number): string => {
    if (amount >= 100000000) {
      return (amount / 100000000).toFixed(2) + '亿'
    } else if (amount >= 10000) {
      return (amount / 10000).toFixed(2) + '万'
    }
    return amount.toFixed(2)
  }

  const tabs = [
    { key: 'realtime', name: '实时跟踪', icon: '📊' },
    { key: 'heartbeat', name: '心跳时刻', icon: '💓' },
    { key: 'dragonTiger', name: '龙虎榜单', icon: '🐉' },
    { key: 'trendLeader', name: '趋势龙头', icon: '🚀' },
    { key: 'newsCatalyst', name: '新闻催化', icon: '📰' },
    { key: 'hotReview', name: '热点复盘', icon: '🔥' }
  ]

  // 实时跟踪 - 行业板块列表（参考同花顺风格）
  const renderIndustryItem = (item: IndustryBoard, index: number) => {
    const isExpanded = expandedBoard === item.board_name
    const isUp = item.change_percent >= 0
    
    return (
      <View key={item.board_name} className="bg-white mb-2">
        {/* 板块主行 */}
        <View 
          className="flex flex-row items-center px-4 py-3 border-b border-slate-100"
          onClick={() => setExpandedBoard(isExpanded ? null : item.board_name)}
        >
          {/* 排名 */}
          <View className="w-8 items-center">
            <Text className={`block text-base font-bold ${index < 3 ? 'text-red-500' : 'text-slate-400'}`}>
              {index + 1}
            </Text>
          </View>
          
          {/* 板块名称 */}
          <View className="flex-1 ml-2">
            <Text className="block text-base font-semibold text-slate-800">{item.board_name}</Text>
            <Text className="block text-xs text-slate-400 mt-1">
              ↑{item.up_count} ↓{item.down_count}
            </Text>
          </View>
          
          {/* 涨幅 */}
          <View className="items-end mr-4">
            <Text className={`block text-lg font-bold ${isUp ? 'text-red-500' : 'text-green-500'}`}>
              {isUp ? '+' : ''}{item.change_percent.toFixed(2)}%
            </Text>
          </View>
          
          {/* 涨速 */}
          <View className="items-end w-16">
            <Text className={`block text-sm ${item.change_speed >= 0 ? 'text-red-400' : 'text-green-400'}`}>
              {item.change_speed >= 0 ? '+' : ''}{item.change_speed.toFixed(2)}
            </Text>
            <Text className="block text-xs text-slate-400 mt-1">涨速</Text>
          </View>
          
          {/* 展开箭头 */}
          <Text className="block text-slate-400 ml-2">{isExpanded ? '▼' : '▶'}</Text>
        </View>
        
        {/* 展开详情 - 领涨股 */}
        {isExpanded && item.top_stocks && item.top_stocks.length > 0 && (
          <View className="bg-slate-50 px-4 py-2">
            <Text className="block text-xs text-slate-500 mb-2">领涨股</Text>
            {item.top_stocks.map((stock, idx) => (
              <View key={idx} className="flex flex-row items-center py-2 border-b border-slate-100 last:border-b-0">
                <View className="flex-1">
                  <Text className="block text-sm font-medium text-slate-800">{stock['名称']}</Text>
                  <Text className="block text-xs text-slate-400">{stock['代码']}</Text>
                </View>
                <View className="items-end">
                  <Text className="block text-sm text-slate-600">¥{stock['最新价'].toFixed(2)}</Text>
                  <Text className={`block text-sm font-medium ${stock['涨跌幅'] >= 0 ? 'text-red-500' : 'text-green-500'}`}>
                    {stock['涨跌幅'] >= 0 ? '+' : ''}{stock['涨跌幅'].toFixed(2)}%
                  </Text>
                </View>
              </View>
            ))}
            
            {/* 板块详细数据 */}
            <View className="flex flex-row mt-3 pt-2 border-t border-slate-200">
              <View className="flex-1 items-center">
                <Text className="block text-xs text-slate-400">换手率</Text>
                <Text className="block text-sm text-slate-600 mt-1">{item.turnover_rate.toFixed(2)}%</Text>
              </View>
              <View className="flex-1 items-center">
                <Text className="block text-xs text-slate-400">成交额</Text>
                <Text className="block text-sm text-slate-600 mt-1">{formatAmount(item.amount)}</Text>
              </View>
              <View className="flex-1 items-center">
                <Text className="block text-xs text-slate-400">上涨家数</Text>
                <Text className="block text-sm text-red-500 mt-1">{item.up_count}</Text>
              </View>
              <View className="flex-1 items-center">
                <Text className="block text-xs text-slate-400">下跌家数</Text>
                <Text className="block text-sm text-green-500 mt-1">{item.down_count}</Text>
              </View>
            </View>
          </View>
        )}
      </View>
    )
  }

  // 心跳时刻 - 涨停股列表
  const renderLimitUpItem = (item: LimitUpStock, index: number) => (
    <View key={item.code + index} className="bg-white rounded-xl p-4 mb-3 border border-slate-200">
      <View className="flex flex-row justify-between items-start">
        <View className="flex-1">
          <View className="flex flex-row items-center mb-1">
            <Text className="block text-base font-semibold text-slate-800 mr-2">{item.name}</Text>
            <View style={{ backgroundColor: '#EF4444', paddingLeft: 6, paddingRight: 6, paddingTop: 2, paddingBottom: 2, borderRadius: 4 }}>
              <Text className="block text-xs text-white font-medium">涨停</Text>
            </View>
          </View>
          <Text className="block text-sm text-slate-500">{item.code}</Text>
          <Text className="block text-xs text-slate-400 mt-1">
            涨停时间: {item.limit_up_time}
            {item.open_count > 0 && ` · 开板${item.open_count}次`}
          </Text>
        </View>
        <View className="text-right">
          <Text className="block text-xl font-bold text-red-500">
            +{item.change_percent.toFixed(2)}%
          </Text>
          <Text className="block text-sm text-slate-600">¥{item.price.toFixed(2)}</Text>
        </View>
      </View>
      
      {/* 涨停原因 */}
      {item.reason && (
        <View className="mt-2 pt-2 border-t border-slate-100">
          <Text className="block text-xs text-slate-500">
            涨停原因: <Text className="text-slate-700">{item.reason}</Text>
          </Text>
          <Text className="block text-xs text-slate-400 mt-1">
            换手率: {item.turnover_rate.toFixed(2)}% · 成交额: {formatAmount(item.amount)}
          </Text>
        </View>
      )}
    </View>
  )

  // 龙虎榜 - 龙虎榜个股列表
  const renderDragonTigerItem = (item: DragonTigerStock, index: number) => {
    const isNetBuy = item.net_buy > 0
    return (
      <View key={item.code + index} className="bg-white rounded-xl p-4 mb-3 border border-slate-200">
        <View className="flex flex-row justify-between items-start">
          <View className="flex-1">
            <View className="flex flex-row items-center mb-1">
              <Text className="block text-base font-semibold text-slate-800 mr-2">{item.name}</Text>
              <Text className="block text-xs text-slate-400">{item.code}</Text>
            </View>
            <Text className="block text-xs text-slate-400 mt-1">
              换手: {item.turnover_rate.toFixed(2)}% · 成交: {formatAmount(item.amount)}
            </Text>
          </View>
          <View className="text-right">
            <Text className={`block text-lg font-bold ${item.change_percent >= 0 ? 'text-red-500' : 'text-green-500'}`}>
              {item.change_percent >= 0 ? '+' : ''}{item.change_percent.toFixed(2)}%
            </Text>
            <Text className="block text-sm text-slate-600">¥{item.price.toFixed(2)}</Text>
          </View>
        </View>
        
        {/* 净买卖 */}
        <View className="mt-3 pt-2 border-t border-slate-100">
          <View className="flex flex-row justify-between items-center mb-2">
            <Text className="block text-xs text-slate-500">净买入:</Text>
            <Text className={`block text-sm font-bold ${isNetBuy ? 'text-red-500' : 'text-green-500'}`}>
              {isNetBuy ? '+' : ''}{formatAmount(item.net_buy)}
            </Text>
          </View>
          
          {/* 买卖金额 */}
          <View className="flex flex-row gap-2 mb-2">
            <View className="flex-1 bg-red-50 rounded-lg p-2">
              <Text className="block text-xs text-slate-500">买入</Text>
              <Text className="block text-sm text-red-500 font-medium">{formatAmount(item.buy_amount)}</Text>
            </View>
            <View className="flex-1 bg-green-50 rounded-lg p-2">
              <Text className="block text-xs text-slate-500">卖出</Text>
              <Text className="block text-sm text-green-500 font-medium">{formatAmount(item.sell_amount)}</Text>
            </View>
          </View>
          
          {/* 知名席位 */}
          {item.famous_buyers && item.famous_buyers.length > 0 && (
            <View className="mb-1">
              <Text className="block text-xs text-slate-500">知名买方:</Text>
              <Text className="block text-xs text-red-600">{item.famous_buyers.join('、')}</Text>
            </View>
          )}
          
          {/* 买卖原因 */}
          {item.buy_reason && (
            <Text className="block text-xs text-slate-400 mt-1">
              {item.buy_reason}
            </Text>
          )}
        </View>
      </View>
    )
  }

  // 趋势龙头 - 趋势龙头个股列表
  const renderTrendLeaderItem = (item: TrendLeaderStock, index: number) => {
    const getStrengthColor = (score: number) => {
      if (score >= 90) return '#EF4444'  // 红色 - 极强
      if (score >= 80) return '#F59E0B'  // 橙色 - 强势
      if (score >= 70) return '#10B981'  // 绿色 - 中等
      return '#64748B'  // 灰色
    }
    
    return (
      <View key={item.code + index} className="bg-white rounded-xl p-4 mb-3 border border-slate-200">
        <View className="flex flex-row justify-between items-start">
          <View className="flex-1">
            <View className="flex flex-row items-center mb-1">
              <Text className="block text-base font-semibold text-slate-800 mr-2">{item.name}</Text>
              <View style={{ backgroundColor: getStrengthColor(item.strength_score) + '20', paddingLeft: 6, paddingRight: 6, paddingTop: 2, paddingBottom: 2, borderRadius: 4 }}>
                <Text className="block text-xs font-medium" style={{ color: getStrengthColor(item.strength_score) }}>
                  {item.strength_score}分
                </Text>
              </View>
            </View>
            <Text className="block text-xs text-slate-400">
              {item.code} · {item.industry}
            </Text>
          </View>
          <View className="text-right">
            <Text className={`block text-lg font-bold ${item.change_percent >= 0 ? 'text-red-500' : 'text-green-500'}`}>
              {item.change_percent >= 0 ? '+' : ''}{item.change_percent.toFixed(2)}%
            </Text>
            <Text className="block text-sm text-slate-600">¥{item.price.toFixed(2)}</Text>
          </View>
        </View>
        
        {/* 趋势指标 */}
        <View className="mt-3 pt-2 border-t border-slate-100">
          <View className="flex flex-row gap-2 mb-2">
            <View className="flex-1 bg-slate-50 rounded-lg p-2 items-center">
              <Text className="block text-xs text-slate-500">连涨天数</Text>
              <Text className="block text-base text-red-500 font-bold">{item.days_rising}天</Text>
            </View>
            <View className="flex-1 bg-slate-50 rounded-lg p-2 items-center">
              <Text className="block text-xs text-slate-500">累计涨幅</Text>
              <Text className="block text-base text-red-500 font-bold">+{item.total_change.toFixed(1)}%</Text>
            </View>
            <View className="flex-1 bg-slate-50 rounded-lg p-2 items-center">
              <Text className="block text-xs text-slate-500">阶段</Text>
              <Text className="block text-xs text-slate-700 font-medium">{item.trend_stage}</Text>
            </View>
          </View>
          
          {/* 支撑/压力位 */}
          <View className="flex flex-row justify-between">
            <View>
              <Text className="block text-xs text-slate-400">支撑位: ¥{item.support_level.toFixed(2)}</Text>
            </View>
            <View>
              <Text className="block text-xs text-slate-400">压力位: ¥{item.resistance_level.toFixed(2)}</Text>
            </View>
          </View>
          
          {/* 市值和换手 */}
          <Text className="block text-xs text-slate-400 mt-2">
            市值: {formatAmount(item.market_cap)} · 换手: {item.turnover_rate.toFixed(2)}%
          </Text>
        </View>
      </View>
    )
  }

  // 新闻催化 - 新闻催化列表
  const renderNewsCatalystItem = (item: NewsCatalyst, index: number) => {
    const getImportanceColor = (importance: string) => {
      switch (importance) {
        case 'high': return '#EF4444'   // 红色 - 重要
        case 'medium': return '#F59E0B' // 橙色 - 一般
        case 'low': return '#64748B'    // 灰色 - 较低
        default: return '#64748B'
      }
    }
    
    const getImportanceLabel = (importance: string) => {
      switch (importance) {
        case 'high': return '重要'
        case 'medium': return '一般'
        case 'low': return '较低'
        default: return '一般'
      }
    }

    const getTypeIcon = (type: string) => {
      switch (type) {
        case '财经新闻': return '📰'
        case '概念热点': return '🔥'
        case '热门个股': return '⭐'
        case '公告速递': return '📢'
        default: return '📌'
      }
    }
    
    return (
      <View key={index} className="bg-white rounded-xl p-4 mb-3 border border-slate-200">
        {/* 标题行 */}
        <View className="flex flex-row items-start mb-2">
          <Text className="block text-lg mr-2">{getTypeIcon(item.type)}</Text>
          <View className="flex-1">
            <View className="flex flex-row items-center flex-wrap mb-1">
              <View 
                style={{ backgroundColor: getImportanceColor(item.importance) + '20', paddingLeft: 6, paddingRight: 6, paddingTop: 2, paddingBottom: 2, borderRadius: 4 }}
                className="mr-2 mb-1"
              >
                <Text className="block text-xs font-medium" style={{ color: getImportanceColor(item.importance) }}>
                  {getImportanceLabel(item.importance)}
                </Text>
              </View>
              <View className="bg-slate-100 px-2 py-0.5 rounded mb-1">
                <Text className="block text-xs text-slate-500">{item.type}</Text>
              </View>
            </View>
            <Text className="block text-base font-semibold text-slate-800 leading-snug">
              {item.title}
            </Text>
          </View>
        </View>
        
        {/* 内容 */}
        <Text className="block text-sm text-slate-600 mb-3 leading-relaxed">
          {item.content}
        </Text>
        
        {/* 相关个股 */}
        {item.stocks && item.stocks.length > 0 && (
          <View className="flex flex-row flex-wrap mb-3">
            {item.stocks.map((stock, idx) => (
              <View 
                key={idx}
                className="bg-red-50 px-2 py-1 rounded mr-2 mb-1"
              >
                <Text className="block text-xs text-red-600 font-medium">{stock}</Text>
              </View>
            ))}
          </View>
        )}
        
        {/* 建议区 */}
        <View className="bg-amber-50 rounded-lg p-3 mb-2">
          <View className="flex flex-row items-center mb-1">
            <Text className="block text-sm mr-1">💡</Text>
            <Text className="block text-xs font-semibold text-amber-700">投资建议</Text>
          </View>
          <Text className="block text-sm text-amber-800 leading-relaxed">
            {item.suggestion}
          </Text>
        </View>
        
        {/* 底部信息 */}
        <View className="flex flex-row justify-between items-center pt-2 border-t border-slate-100">
          <Text className="block text-xs text-slate-400">{item.source}</Text>
          <Text className="block text-xs text-slate-400">{item.publish_time}</Text>
        </View>
      </View>
    )
  }

  const renderContent = () => {
    if (!isLoggedIn) return null

    switch (activeTab) {
      case 'realtime':
        return (
          <ScrollView scrollY className="h-full">
            <View className="p-4">
              {/* 标题和数据来源 */}
              <View className="flex flex-row justify-between items-center mb-4">
                <View>
                  <Text className="block text-lg font-semibold text-slate-800">行业板块实时行情</Text>
                  <View className="flex flex-row items-center mt-1">
                    <View 
                      className="px-2 py-0.5 rounded mr-2"
                      style={{ backgroundColor: getSourceColor(industrySource) + '20', paddingLeft: 8, paddingRight: 8, paddingTop: 2, paddingBottom: 2 }}
                    >
                      <Text className="block text-xs" style={{ color: getSourceColor(industrySource) }}>
                        {getSourceLabel(industrySource)}
                      </Text>
                    </View>
                    {industryUpdateTime && (
                      <Text className="block text-xs text-slate-400">
                        更新: {formatTime(industryUpdateTime)}
                      </Text>
                    )}
                  </View>
                </View>
                <View 
                  className="bg-orange-50 px-3 py-1 rounded-full"
                  onClick={() => { setLoading(true); loadIndustryData().finally(() => setLoading(false)) }}
                >
                  <Text className="block text-xs text-orange-500">刷新</Text>
                </View>
              </View>
              
              {/* 表头 */}
              <View className="flex flex-row items-center px-4 py-2 bg-slate-100 rounded-t-lg">
                <View className="w-8"><Text className="block text-xs text-slate-500">排名</Text></View>
                <View className="flex-1 ml-2"><Text className="block text-xs text-slate-500">板块名称</Text></View>
                <View className="w-16 items-end"><Text className="block text-xs text-slate-500">涨速</Text></View>
                <View className="w-20 items-end mr-2"><Text className="block text-xs text-slate-500">涨幅</Text></View>
              </View>
              
              {/* 板块列表 */}
              {industryData.length > 0 ? (
                industryData.map((item, idx) => renderIndustryItem(item, idx))
              ) : (
                <View className="flex items-center justify-center py-16">
                  <Text className="block text-slate-400">暂无数据</Text>
                </View>
              )}
            </View>
          </ScrollView>
        )
      case 'heartbeat':
        return (
          <ScrollView scrollY className="h-full">
            <View className="p-4">
              <View className="flex flex-row justify-between items-center mb-4">
                <View>
                  <Text className="block text-lg font-semibold text-slate-800">今日涨停个股</Text>
                  <View className="flex flex-row items-center mt-1">
                    <View 
                      className="px-2 py-0.5 rounded mr-2"
                      style={{ backgroundColor: getSourceColor(limitUpSource) + '20', paddingLeft: 8, paddingRight: 8, paddingTop: 2, paddingBottom: 2 }}
                    >
                      <Text className="block text-xs" style={{ color: getSourceColor(limitUpSource) }}>
                        {getSourceLabel(limitUpSource)}
                      </Text>
                    </View>
                    {limitUpUpdateTime && (
                      <Text className="block text-xs text-slate-400">
                        更新: {formatTime(limitUpUpdateTime)}
                      </Text>
                    )}
                  </View>
                </View>
                <View 
                  className="bg-red-50 px-3 py-1 rounded-full"
                  onClick={() => { setLoading(true); loadLimitUpStocks().finally(() => setLoading(false)) }}
                >
                  <Text className="block text-xs text-red-500">刷新</Text>
                </View>
              </View>
              
              {limitUpStocks.length > 0 ? (
                limitUpStocks.map((item, idx) => renderLimitUpItem(item, idx))
              ) : (
                <View className="flex items-center justify-center py-16">
                  <Text className="block text-slate-400">暂无涨停数据</Text>
                </View>
              )}
            </View>
          </ScrollView>
        )
      case 'dragonTiger':
        return (
          <ScrollView scrollY className="h-full">
            <View className="p-4">
              <View className="flex flex-row justify-between items-center mb-4">
                <View>
                  <Text className="block text-lg font-semibold text-slate-800">今日龙虎榜</Text>
                  <View className="flex flex-row items-center mt-1">
                    <View 
                      className="px-2 py-0.5 rounded mr-2"
                      style={{ backgroundColor: getSourceColor(dragonTigerSource) + '20', paddingLeft: 8, paddingRight: 8, paddingTop: 2, paddingBottom: 2 }}
                    >
                      <Text className="block text-xs" style={{ color: getSourceColor(dragonTigerSource) }}>
                        {getSourceLabel(dragonTigerSource)}
                      </Text>
                    </View>
                    {dragonTigerUpdateTime && (
                      <Text className="block text-xs text-slate-400">
                        更新: {formatTime(dragonTigerUpdateTime)}
                      </Text>
                    )}
                  </View>
                </View>
                <View 
                  className="bg-purple-50 px-3 py-1 rounded-full"
                  onClick={() => { setLoading(true); loadDragonTigerData().finally(() => setLoading(false)) }}
                >
                  <Text className="block text-xs text-purple-500">刷新</Text>
                </View>
              </View>
              
              {dragonTigerData.length > 0 ? (
                dragonTigerData.map((item, idx) => renderDragonTigerItem(item, idx))
              ) : (
                <View className="flex items-center justify-center py-16">
                  <Text className="block text-slate-400">暂无龙虎榜数据</Text>
                </View>
              )}
            </View>
          </ScrollView>
        )
      case 'trendLeader':
        return (
          <ScrollView scrollY className="h-full">
            <View className="p-4">
              <View className="flex flex-row justify-between items-center mb-4">
                <View>
                  <Text className="block text-lg font-semibold text-slate-800">趋势龙头股</Text>
                  <View className="flex flex-row items-center mt-1">
                    <View 
                      className="px-2 py-0.5 rounded mr-2"
                      style={{ backgroundColor: getSourceColor(trendLeaderSource) + '20', paddingLeft: 8, paddingRight: 8, paddingTop: 2, paddingBottom: 2 }}
                    >
                      <Text className="block text-xs" style={{ color: getSourceColor(trendLeaderSource) }}>
                        {getSourceLabel(trendLeaderSource)}
                      </Text>
                    </View>
                    {trendLeaderUpdateTime && (
                      <Text className="block text-xs text-slate-400">
                        更新: {formatTime(trendLeaderUpdateTime)}
                      </Text>
                    )}
                  </View>
                </View>
                <View 
                  className="bg-blue-50 px-3 py-1 rounded-full"
                  onClick={() => { setLoading(true); loadTrendLeaderData().finally(() => setLoading(false)) }}
                >
                  <Text className="block text-xs text-blue-500">刷新</Text>
                </View>
              </View>
              
              {trendLeaderData.length > 0 ? (
                trendLeaderData.map((item, idx) => renderTrendLeaderItem(item, idx))
              ) : (
                <View className="flex items-center justify-center py-16">
                  <Text className="block text-slate-400">暂无趋势龙头数据</Text>
                </View>
              )}
            </View>
          </ScrollView>
        )
      case 'newsCatalyst':
        return (
          <ScrollView scrollY className="h-full">
            <View className="p-4">
              <View className="flex flex-row justify-between items-center mb-4">
                <View>
                  <Text className="block text-lg font-semibold text-slate-800">新闻催化</Text>
                  <View className="flex flex-row items-center mt-1">
                    <View 
                      className="px-2 py-0.5 rounded mr-2"
                      style={{ backgroundColor: getSourceColor(newsCatalystSource) + '20', paddingLeft: 8, paddingRight: 8, paddingTop: 2, paddingBottom: 2 }}
                    >
                      <Text className="block text-xs" style={{ color: getSourceColor(newsCatalystSource) }}>
                        {getSourceLabel(newsCatalystSource)}
                      </Text>
                    </View>
                    {newsCatalystUpdateTime && (
                      <Text className="block text-xs text-slate-400">
                        更新: {formatTime(newsCatalystUpdateTime)}
                      </Text>
                    )}
                  </View>
                </View>
                <View 
                  className="bg-indigo-50 px-3 py-1 rounded-full"
                  onClick={() => { setLoading(true); loadNewsCatalystData().finally(() => setLoading(false)) }}
                >
                  <Text className="block text-xs text-indigo-500">刷新</Text>
                </View>
              </View>
              
              {newsCatalystData.length > 0 ? (
                newsCatalystData.map((item, idx) => renderNewsCatalystItem(item, idx))
              ) : (
                <View className="flex items-center justify-center py-16">
                  <Text className="block text-slate-400">暂无新闻数据</Text>
                </View>
              )}
            </View>
          </ScrollView>
        )
      case 'hotReview':
        return (
          <ScrollView scrollY className="h-full">
            <View className="p-4">
              <View className="flex flex-row justify-between items-center mb-4">
                <View>
                  <Text className="block text-lg font-semibold text-slate-800">热点复盘</Text>
                  <View className="flex flex-row items-center mt-1">
                    <View 
                      className="px-2 py-0.5 rounded mr-2"
                      style={{ backgroundColor: getSourceColor(hotReviewSource) + '20', paddingLeft: 8, paddingRight: 8, paddingTop: 2, paddingBottom: 2 }}
                    >
                      <Text className="block text-xs" style={{ color: getSourceColor(hotReviewSource) }}>
                        {getSourceLabel(hotReviewSource)}
                      </Text>
                    </View>
                    {hotReviewUpdateTime && (
                      <Text className="block text-xs text-slate-400">
                        更新: {formatTime(hotReviewUpdateTime)}
                      </Text>
                    )}
                  </View>
                </View>
                <View 
                  className="bg-red-50 px-3 py-1 rounded-full"
                  onClick={() => { setLoading(true); loadHotReviewData().finally(() => setLoading(false)) }}
                >
                  <Text className="block text-xs text-red-500">刷新</Text>
                </View>
              </View>
              
              {hotReviewData ? (
                <>
                  {/* 市场概述 */}
                  <View className="bg-gradient-to-r from-orange-50 to-red-50 rounded-xl p-4 mb-4 border border-orange-100">
                    <View className="flex flex-row items-center mb-2">
                      <Text className="block text-lg mr-2">📈</Text>
                      <Text className="block text-base font-semibold text-slate-800">市场概述</Text>
                    </View>
                    <Text className="block text-sm text-slate-600 leading-relaxed">
                      {hotReviewData.summary}
                    </Text>
                    {hotReviewData.date && (
                      <Text className="block text-xs text-slate-400 mt-2">日期: {hotReviewData.date}</Text>
                    )}
                  </View>

                  {/* 热门股票热度榜 */}
                  <View className="bg-white rounded-xl p-4 mb-4 border border-slate-200">
                    <View className="flex flex-row items-center mb-3">
                      <Text className="block text-lg mr-2">🏆</Text>
                      <Text className="block text-base font-semibold text-slate-800">热门股票热度榜</Text>
                    </View>
                    
                    {hotReviewData.hot_stocks && hotReviewData.hot_stocks.length > 0 ? (
                      hotReviewData.hot_stocks.map((stock, idx) => (
                        <View key={stock.code + idx} className="border-b border-slate-100 py-3 last:border-b-0">
                          <View className="flex flex-row justify-between items-start">
                            <View className="flex-1">
                              <View className="flex flex-row items-center">
                                {/* 热度排名 */}
                                <View 
                                  className="w-6 h-6 rounded-full items-center justify-center mr-2"
                                  style={{ backgroundColor: idx < 3 ? '#EF4444' : '#94A3B8' }}
                                >
                                  <Text className="block text-xs text-white font-bold">{idx + 1}</Text>
                                </View>
                                <Text className="block text-base font-semibold text-slate-800 mr-2">{stock.name}</Text>
                                <Text className="block text-xs text-slate-400">{stock.code}</Text>
                              </View>
                              {/* 热度来源 */}
                              <View className="flex flex-row flex-wrap mt-1">
                                {stock.heat_sources && stock.heat_sources.map((source, sIdx) => (
                                  <View key={sIdx} className="bg-orange-50 px-2 py-0.5 rounded mr-1 mb-1">
                                    <Text className="block text-xs text-orange-600">{source}</Text>
                                  </View>
                                ))}
                              </View>
                            </View>
                            <View className="items-end">
                              <Text className={`block text-lg font-bold ${stock.change_percent >= 0 ? 'text-red-500' : 'text-green-500'}`}>
                                {stock.change_percent >= 0 ? '+' : ''}{stock.change_percent.toFixed(2)}%
                              </Text>
                              <Text className="block text-xs text-slate-500">¥{stock.price.toFixed(2)}</Text>
                              {/* 热度分数 */}
                              <View className="flex flex-row items-center mt-1">
                                <Text className="block text-xs text-orange-500 mr-1">🔥</Text>
                                <Text className="block text-xs font-semibold text-orange-500">{stock.heat_score}分</Text>
                              </View>
                            </View>
                          </View>
                          
                          {/* 热门原因 */}
                          {stock.reasons && stock.reasons.length > 0 && (
                            <View className="mt-2 pt-2 border-t border-slate-50">
                              <Text className="block text-xs text-slate-500 mb-1">热门原因:</Text>
                              {stock.reasons.map((reason, rIdx) => (
                                <Text key={rIdx} className="block text-xs text-slate-600">• {reason}</Text>
                              ))}
                            </View>
                          )}
                          
                          {/* 相关概念 */}
                          {stock.related_concepts && stock.related_concepts.length > 0 && (
                            <View className="flex flex-row flex-wrap mt-2">
                              {stock.related_concepts.map((concept, cIdx) => (
                                <View key={cIdx} className="bg-blue-50 px-2 py-0.5 rounded mr-1 mb-1">
                                  <Text className="block text-xs text-blue-600">{concept}</Text>
                                </View>
                              ))}
                            </View>
                          )}
                          
                          {/* 投资建议 */}
                          <View className="mt-2 bg-amber-50 rounded-lg p-2">
                            <View className="flex flex-row items-center justify-between mb-1">
                              <View className="flex flex-row items-center">
                                <Text className="block text-sm mr-1">💡</Text>
                                <Text className="block text-xs font-semibold text-amber-700">投资建议</Text>
                              </View>
                              {/* 风险等级 */}
                              <View 
                                className="px-2 py-0.5 rounded"
                                style={{ 
                                  backgroundColor: stock.risk_level === 'high' ? '#FEE2E2' : stock.risk_level === 'medium' ? '#FEF3C7' : '#D1FAE5'
                                }}
                              >
                                <Text 
                                  className="block text-xs font-medium"
                                  style={{ 
                                    color: stock.risk_level === 'high' ? '#DC2626' : stock.risk_level === 'medium' ? '#D97706' : '#059669'
                                  }}
                                >
                                  {stock.risk_level === 'high' ? '高风险' : stock.risk_level === 'medium' ? '中风险' : '低风险'}
                                </Text>
                              </View>
                            </View>
                            <Text className="block text-sm text-amber-800 leading-relaxed">{stock.suggestion}</Text>
                          </View>
                        </View>
                      ))
                    ) : (
                      <View className="flex items-center justify-center py-8">
                        <Text className="block text-slate-400">暂无热门股票数据</Text>
                      </View>
                    )}
                  </View>

                  {/* 头条新闻 */}
                  {hotReviewData.top_news && hotReviewData.top_news.length > 0 && (
                    <View className="bg-white rounded-xl p-4 mb-4 border border-slate-200">
                      <View className="flex flex-row items-center mb-3">
                        <Text className="block text-lg mr-2">📰</Text>
                        <Text className="block text-base font-semibold text-slate-800">财经头条</Text>
                      </View>
                      {hotReviewData.top_news.map((news, idx) => (
                        <View key={idx} className="py-2 border-b border-slate-100 last:border-b-0">
                          <Text className="block text-sm text-slate-800">{news.title}</Text>
                          <View className="flex flex-row justify-between mt-1">
                            <Text className="block text-xs text-slate-400">{news.source}</Text>
                            <Text className="block text-xs text-slate-400">{news.time}</Text>
                          </View>
                        </View>
                      ))}
                    </View>
                  )}

                  {/* AI 分析 */}
                  {hotReviewData.analysis && (
                    <View className="bg-gradient-to-r from-purple-50 to-indigo-50 rounded-xl p-4 mb-4 border border-purple-100">
                      <View className="flex flex-row items-center mb-2">
                        <Text className="block text-lg mr-2">🤖</Text>
                        <Text className="block text-base font-semibold text-slate-800">AI 深度分析</Text>
                      </View>
                      <Text className="block text-sm text-slate-600 leading-relaxed whitespace-pre-wrap">
                        {hotReviewData.analysis}
                      </Text>
                    </View>
                  )}
                </>
              ) : (
                <View className="flex items-center justify-center py-16">
                  <Text className="block text-slate-400">暂无热点复盘数据</Text>
                </View>
              )}
            </View>
          </ScrollView>
        )
      default:
        return null
    }
  }

  if (!isLoggedIn) {
    return (
      <View className="flex items-center justify-center min-h-screen">
        <Text className="block text-slate-400">正在验证登录状态...</Text>
      </View>
    )
  }

  return (
    <View className="flex flex-col min-h-screen bg-slate-100">
      {/* 顶部欢迎区域 */}
      <View className="bg-gradient-to-r from-orange-500 to-orange-600 p-6 pb-8">
        <View className="flex flex-row justify-between items-start">
          <View>
            <Text className="block text-2xl font-bold text-white mb-2">🐰 小兔快跑</Text>
            <Text className="block text-sm text-orange-100">AI驱动的金融数据分析工具</Text>
          </View>
          <View className="flex flex-row gap-2">
            {/* 管理员入口 - 只有管理员可见 */}
            {isAdmin && (
              <View
                style={{
                  backgroundColor: 'rgba(255, 255, 255, 0.2)',
                  padding: '4px 12px',
                  borderRadius: 20
                }}
                onClick={() => Taro.navigateTo({ url: '/pages/admin/index' })}
              >
                <Text className="block text-xs text-white font-medium">管理</Text>
              </View>
            )}
            {/* 退出登录 */}
            <View
              style={{
                backgroundColor: 'rgba(255, 255, 255, 0.2)',
                padding: '4px 12px',
                borderRadius: 20
              }}
              onClick={() => {
                Taro.showModal({
                  title: '确认退出',
                  content: '确定要退出登录吗？',
                  success: (res) => {
                    if (res.confirm) {
                      Taro.removeStorageSync('isLoggedIn')
                      Taro.removeStorageSync('userInfo')
                      Taro.removeStorageSync('userRole')
                      Taro.redirectTo({ url: '/pages/login/index' })
                    }
                  }
                })
              }}
            >
              <Text className="block text-xs text-white font-medium">退出</Text>
            </View>
          </View>
        </View>
      </View>

      {/* Tab 栏目切换 */}
      <View className="bg-white border-b border-slate-200 px-2">
        <View className="flex flex-row">
          {tabs.map((tab) => (
            <View
              key={tab.key}
              className="flex-1 py-3 items-center"
              onClick={() => setActiveTab(tab.key as TabType)}
            >
              <Text className="block text-lg mb-1">{tab.icon}</Text>
              <Text className={`block text-sm ${activeTab === tab.key ? 'text-orange-500 font-semibold' : 'text-slate-600'}`}>
                {tab.name}
              </Text>
              {activeTab === tab.key && (
                <View className="w-8 h-1 bg-orange-500 rounded-full mt-2" />
              )}
            </View>
          ))}
        </View>
      </View>

      {/* 内容区域 */}
      <View className="flex-1">
        {loading ? (
          <View className="flex items-center justify-center py-16">
            <Text className="block text-slate-400">加载中...</Text>
          </View>
        ) : (
          renderContent()
        )}
      </View>

      {/* 风险提示 */}
      <View className="p-4 bg-amber-50 border-t border-amber-200">
        <Text className="block text-xs text-amber-700 text-center">
          ⚠️ 数据仅供参考，不作为投资依据{'\n'}
          股市有风险，投资需谨慎
        </Text>
      </View>
    </View>
  )
}

export default IndexPage
