import { Injectable } from '@nestjs/common';
import { getSupabaseClient } from '@/storage/database/supabase-client';
import { exec } from 'child_process';
import { promisify } from 'util';

const execAsync = promisify(exec);

@Injectable()
export class StockService {
  // 获取行业板块数据
  async getIndustryData() {
    const client = getSupabaseClient();
    
    // 尝试从AKSHARE获取真实数据
    try {
      console.log('尝试从AKSHARE获取行业板块数据...');
      const { stdout, stderr } = await execAsync('python3 server/scripts/akshare_data.py industry', {
        timeout: 30000,
      });
      
      if (stderr) {
        console.error('Python stderr:', stderr);
      }
      
      const result = JSON.parse(stdout);
      
      if (result.code === 200 && result.data && result.data.length > 0) {
        console.log('成功获取AKSHARE数据:', result.data.length, '个板块');
        
        // 更新缓存
        await client
          .from('stock_cache')
          .upsert({
            data_type: 'industry',
            data_content: result.data,
          }, { onConflict: 'data_type' });
        
        return {
          data: result.data,
          source: 'akshare',
          updateTime: new Date().toISOString()
        };
      }
    } catch (error) {
      console.error('AKSHARE获取失败:', error.message);
    }
    
    // 尝试从缓存获取
    const { data: cache } = await client
      .from('stock_cache')
      .select('*')
      .eq('data_type', 'industry')
      .single();

    if (cache && cache.data_content && cache.data_content.length > 0) {
      console.log('使用缓存数据');
      return {
        data: cache.data_content,
        source: 'cache',
        updateTime: cache.updated_at
      };
    }
    
    // 使用模拟数据
    console.log('使用模拟数据');
    const mockData = this.getMockIndustryData();
    
    return {
      data: mockData,
      source: 'mock',
      updateTime: new Date().toISOString()
    };
  }

  // 获取涨停个股数据
  async getLimitUpStocks() {
    const client = getSupabaseClient();
    
    // 尝试从AKSHARE获取真实数据
    try {
      console.log('尝试从AKSHARE获取涨停数据...');
      const { stdout, stderr } = await execAsync('python3 server/scripts/akshare_data.py limit_up', {
        timeout: 30000,
      });
      
      if (stderr) {
        console.error('Python stderr:', stderr);
      }
      
      const result = JSON.parse(stdout);
      
      if (result.code === 200 && result.data && result.data.length > 0) {
        console.log('成功获取涨停数据:', result.data.length, '只');
        
        // 更新缓存
        await client
          .from('stock_cache')
          .upsert({
            data_type: 'limit_up',
            data_content: result.data,
          }, { onConflict: 'data_type' });
        
        return {
          data: result.data,
          source: 'akshare',
          updateTime: new Date().toISOString()
        };
      }
    } catch (error) {
      console.error('AKSHARE涨停数据获取失败:', error.message);
    }
    
    // 尝试从缓存获取
    const { data: cache } = await client
      .from('stock_cache')
      .select('*')
      .eq('data_type', 'limit_up')
      .single();

    if (cache && cache.data_content && cache.data_content.length > 0) {
      console.log('使用缓存涨停数据');
      return {
        data: cache.data_content,
        source: 'cache',
        updateTime: cache.updated_at
      };
    }
    
    // 使用模拟数据
    console.log('使用模拟涨停数据');
    const mockData = this.getMockLimitUpData();
    
    return {
      data: mockData,
      source: 'mock',
      updateTime: new Date().toISOString()
    };
  }

  // 模拟数据（更加真实的数据）
  private getMockIndustryData() {
    const now = new Date();
    const baseData = [
      {
        board_name: '小金属',
        board_code: 'BK0428',
        change_percent: 4.56 + (Math.random() - 0.5) * 0.5,
        change_speed: 0.32 + (Math.random() - 0.5) * 0.1,
        latest_price: 1256.78 + (Math.random() - 0.5) * 10,
        turnover_rate: 3.25,
        amount: 1256890000,
        up_count: 28,
        down_count: 5,
        top_stocks: [
          { '代码': '002466', '名称': '天齐锂业', '最新价': 58.90, '涨跌幅': 9.98, '涨速': 0.15 },
          { '代码': '002460', '名称': '赣锋锂业', '最新价': 42.35, '涨跌幅': 8.65, '涨速': 0.12 },
          { '代码': '300037', '名称': '新宙邦', '最新价': 85.60, '涨跌幅': 7.23, '涨速': 0.08 }
        ]
      },
      {
        board_name: '电池',
        board_code: 'BK0452',
        change_percent: 3.89 + (Math.random() - 0.5) * 0.5,
        change_speed: 0.28 + (Math.random() - 0.5) * 0.1,
        latest_price: 1856.50 + (Math.random() - 0.5) * 20,
        turnover_rate: 2.86,
        amount: 2568900000,
        up_count: 35,
        down_count: 8,
        top_stocks: [
          { '代码': '300750', '名称': '宁德时代', '最新价': 198.50, '涨跌幅': 6.89, '涨速': 0.22 },
          { '代码': '002594', '名称': '比亚迪', '最新价': 256.80, '涨跌幅': 5.45, '涨速': 0.18 },
          { '代码': '300124', '名称': '汇川技术', '最新价': 68.90, '涨跌幅': 4.56, '涨速': 0.11 }
        ]
      },
      {
        board_name: '白酒',
        board_code: 'BK0477',
        change_percent: 2.35 + (Math.random() - 0.5) * 0.3,
        change_speed: 0.15 + (Math.random() - 0.5) * 0.05,
        latest_price: 2568.90 + (Math.random() - 0.5) * 30,
        turnover_rate: 1.56,
        amount: 3568900000,
        up_count: 18,
        down_count: 2,
        top_stocks: [
          { '代码': '600519', '名称': '贵州茅台', '最新价': 1856.50, '涨跌幅': 3.25, '涨速': 0.08 },
          { '代码': '000858', '名称': '五粮液', '最新价': 158.20, '涨跌幅': 2.98, '涨速': 0.06 },
          { '代码': '000568', '名称': '泸州老窖', '最新价': 198.60, '涨跌幅': 2.56, '涨速': 0.05 }
        ]
      },
      {
        board_name: '半导体',
        board_code: 'BK0892',
        change_percent: 1.86 + (Math.random() - 0.5) * 0.4,
        change_speed: 0.12 + (Math.random() - 0.5) * 0.08,
        latest_price: 1256.78 + (Math.random() - 0.5) * 15,
        turnover_rate: 2.35,
        amount: 1896500000,
        up_count: 42,
        down_count: 15,
        top_stocks: [
          { '代码': '002415', '名称': '海康威视', '最新价': 32.50, '涨跌幅': 4.56, '涨速': 0.09 },
          { '代码': '603501', '名称': '韦尔股份', '最新价': 98.60, '涨跌幅': 3.89, '涨速': 0.07 },
          { '代码': '002371', '名称': '北方华创', '最新价': 286.50, '涨跌幅': 3.12, '涨速': 0.05 }
        ]
      },
      {
        board_name: '汽车整车',
        board_code: 'BK0896',
        change_percent: 1.52 + (Math.random() - 0.5) * 0.3,
        change_speed: 0.18 + (Math.random() - 0.5) * 0.06,
        latest_price: 2156.30 + (Math.random() - 0.5) * 25,
        turnover_rate: 2.15,
        amount: 2856000000,
        up_count: 25,
        down_count: 12,
        top_stocks: [
          { '代码': '601127', '名称': '小康股份', '最新价': 68.50, '涨跌幅': 5.23, '涨速': 0.12 },
          { '代码': '601238', '名称': '广汽集团', '最新价': 12.80, '涨跌幅': 3.56, '涨速': 0.08 },
          { '代码': '000625', '名称': '长安汽车', '最新价': 15.60, '涨跌幅': 2.89, '涨速': 0.06 }
        ]
      },
      {
        board_name: '光伏设备',
        board_code: 'BK0727',
        change_percent: 1.28 + (Math.random() - 0.5) * 0.4,
        change_speed: 0.22 + (Math.random() - 0.5) * 0.1,
        latest_price: 1856.90 + (Math.random() - 0.5) * 20,
        turnover_rate: 2.68,
        amount: 1568900000,
        up_count: 22,
        down_count: 10,
        top_stocks: [
          { '代码': '601012', '名称': '隆基绿能', '最新价': 38.60, '涨跌幅': 4.12, '涨速': 0.15 },
          { '代码': '300274', '名称': '阳光电源', '最新价': 98.50, '涨跌幅': 3.56, '涨速': 0.11 },
          { '代码': '002459', '名称': '晶澳科技', '最新价': 45.80, '涨跌幅': 2.98, '涨速': 0.08 }
        ]
      },
      {
        board_name: '医药商业',
        board_code: 'BK0732',
        change_percent: -0.52 + (Math.random() - 0.5) * 0.3,
        change_speed: -0.08 + (Math.random() - 0.5) * 0.05,
        latest_price: 856.90 + (Math.random() - 0.5) * 10,
        turnover_rate: 1.25,
        amount: 856900000,
        up_count: 8,
        down_count: 22,
        top_stocks: [
          { '代码': '603259', '名称': '药明康德', '最新价': 68.90, '涨跌幅': 1.56, '涨速': 0.03 },
          { '代码': '300760', '名称': '迈瑞医疗', '最新价': 298.50, '涨跌幅': 0.89, '涨速': 0.02 },
          { '代码': '000661', '名称': '长春高新', '最新价': 145.30, '涨跌幅': -2.35, '涨速': -0.05 }
        ]
      },
      {
        board_name: '银行',
        board_code: 'BK0478',
        change_percent: 0.78 + (Math.random() - 0.5) * 0.2,
        change_speed: 0.05 + (Math.random() - 0.5) * 0.02,
        latest_price: 986.50 + (Math.random() - 0.5) * 8,
        turnover_rate: 0.85,
        amount: 12569000000,
        up_count: 32,
        down_count: 10,
        top_stocks: [
          { '代码': '600036', '名称': '招商银行', '最新价': 35.80, '涨跌幅': 1.28, '涨速': 0.02 },
          { '代码': '601166', '名称': '兴业银行', '最新价': 18.56, '涨跌幅': 1.12, '涨速': 0.02 },
          { '代码': '000001', '名称': '平安银行', '最新价': 12.45, '涨跌幅': 0.89, '涨速': 0.01 }
        ]
      },
      {
        board_name: '房地产',
        board_code: 'BK0451',
        change_percent: -1.25 + (Math.random() - 0.5) * 0.4,
        change_speed: -0.15 + (Math.random() - 0.5) * 0.08,
        latest_price: 1256.30 + (Math.random() - 0.5) * 15,
        turnover_rate: 1.56,
        amount: 2156800000,
        up_count: 12,
        down_count: 38,
        top_stocks: [
          { '代码': '000002', '名称': '万科A', '最新价': 12.80, '涨跌幅': 0.56, '涨速': 0.01 },
          { '代码': '001979', '名称': '招商蛇口', '最新价': 15.60, '涨跌幅': -0.89, '涨速': -0.02 },
          { '代码': '600048', '名称': '保利发展', '最新价': 11.20, '涨跌幅': -1.56, '涨速': -0.03 }
        ]
      },
      {
        board_name: '计算机应用',
        board_code: 'BK0712',
        change_percent: 0.95 + (Math.random() - 0.5) * 0.5,
        change_speed: 0.08 + (Math.random() - 0.5) * 0.06,
        latest_price: 3568.90 + (Math.random() - 0.5) * 40,
        turnover_rate: 2.86,
        amount: 1856900000,
        up_count: 48,
        down_count: 22,
        top_stocks: [
          { '代码': '300033', '名称': '同花顺', '最新价': 85.60, '涨跌幅': 5.68, '涨速': 0.18 },
          { '代码': '002230', '名称': '科大讯飞', '最新价': 48.90, '涨跌幅': 4.12, '涨速': 0.12 },
          { '代码': '300368', '名称': '汇金股份', '最新价': 25.60, '涨跌幅': 3.56, '涨速': 0.09 }
        ]
      }
    ];
    
    // 按涨幅排序
    return baseData.sort((a, b) => b.change_percent - a.change_percent);
  }

  private getMockLimitUpData() {
    return [
      { 
        code: '002466', 
        name: '天齐锂业', 
        price: 58.90, 
        change_percent: 9.98, 
        limit_up_time: '09:30:00', 
        first_limit_up_time: '09:25:00', 
        open_count: 0, 
        turnover_rate: 3.25, 
        amount: 1256890000, 
        reason: '锂电池龙头，新能源概念' 
      },
      { 
        code: '300750', 
        name: '宁德时代', 
        price: 198.50, 
        change_percent: 9.99, 
        limit_up_time: '09:35:00', 
        first_limit_up_time: '09:30:00', 
        open_count: 0, 
        turnover_rate: 2.86, 
        amount: 2568900000, 
        reason: '动力电池龙头' 
      },
      { 
        code: '002594', 
        name: '比亚迪', 
        price: 256.80, 
        change_percent: 9.99, 
        limit_up_time: '09:40:00', 
        first_limit_up_time: '09:38:00', 
        open_count: 1, 
        turnover_rate: 1.56, 
        amount: 3896500000, 
        reason: '新能源汽车龙头' 
      },
      { 
        code: '600519', 
        name: '贵州茅台', 
        price: 1856.50, 
        change_percent: 9.98, 
        limit_up_time: '09:45:00', 
        first_limit_up_time: '09:42:00', 
        open_count: 0, 
        turnover_rate: 0.35, 
        amount: 256890000, 
        reason: '白酒龙头，业绩超预期' 
      },
      { 
        code: '000858', 
        name: '五粮液', 
        price: 158.20, 
        change_percent: 9.99, 
        limit_up_time: '10:00:00', 
        first_limit_up_time: '09:55:00', 
        open_count: 2, 
        turnover_rate: 0.45, 
        amount: 189650000, 
        reason: '白酒板块跟涨' 
      },
      { 
        code: '601012', 
        name: '隆基绿能', 
        price: 38.60, 
        change_percent: 9.98, 
        limit_up_time: '10:15:00', 
        first_limit_up_time: '10:12:00', 
        open_count: 0, 
        turnover_rate: 2.68, 
        amount: 1568900000, 
        reason: '光伏龙头，碳中和概念' 
      },
      { 
        code: '300033', 
        name: '同花顺', 
        price: 85.60, 
        change_percent: 9.99, 
        limit_up_time: '10:30:00', 
        first_limit_up_time: '10:25:00', 
        open_count: 0, 
        turnover_rate: 2.86, 
        amount: 856900000, 
        reason: '金融科技，行情火爆' 
      },
      { 
        code: '002415', 
        name: '海康威视', 
        price: 32.50, 
        change_percent: 9.98, 
        limit_up_time: '10:45:00', 
        first_limit_up_time: '10:40:00', 
        open_count: 1, 
        turnover_rate: 2.35, 
        amount: 1896500000, 
        reason: 'AI概念，安防龙头' 
      }
    ];
  }

  // 获取龙虎榜数据
  async getDragonTigerData() {
    const client = getSupabaseClient();
    
    // 尝试从AKSHARE获取真实数据
    try {
      console.log('尝试从AKSHARE获取龙虎榜数据...');
      const { stdout, stderr } = await execAsync('python3 server/scripts/akshare_data.py dragon_tiger', {
        timeout: 30000,
      });
      
      if (stderr) {
        console.error('Python stderr:', stderr);
      }
      
      const result = JSON.parse(stdout);
      
      if (result.code === 200 && result.data && result.data.length > 0) {
        console.log('成功获取龙虎榜数据:', result.data.length, '只');
        
        // 更新缓存
        await client
          .from('stock_cache')
          .upsert({
            data_type: 'dragon_tiger',
            data_content: result.data,
          }, { onConflict: 'data_type' });
        
        return {
          data: result.data,
          source: 'akshare',
          updateTime: new Date().toISOString()
        };
      }
    } catch (error) {
      console.error('AKSHARE龙虎榜数据获取失败:', error.message);
    }
    
    // 尝试从缓存获取
    const { data: cache } = await client
      .from('stock_cache')
      .select('*')
      .eq('data_type', 'dragon_tiger')
      .single();

    if (cache && cache.data_content && cache.data_content.length > 0) {
      console.log('使用缓存龙虎榜数据');
      return {
        data: cache.data_content,
        source: 'cache',
        updateTime: cache.updated_at
      };
    }
    
    // 使用模拟数据
    console.log('使用模拟龙虎榜数据');
    const mockData = this.getMockDragonTigerData();
    
    return {
      data: mockData,
      source: 'mock',
      updateTime: new Date().toISOString()
    };
  }

  // 获取趋势龙头数据
  async getTrendLeaderData() {
    const client = getSupabaseClient();
    
    // 尝试从AKSHARE获取真实数据
    try {
      console.log('尝试从AKSHARE获取趋势龙头数据...');
      const { stdout, stderr } = await execAsync('python3 server/scripts/akshare_data.py trend_leader', {
        timeout: 30000,
      });
      
      if (stderr) {
        console.error('Python stderr:', stderr);
      }
      
      const result = JSON.parse(stdout);
      
      if (result.code === 200 && result.data && result.data.length > 0) {
        console.log('成功获取趋势龙头数据:', result.data.length, '只');
        
        // 更新缓存
        await client
          .from('stock_cache')
          .upsert({
            data_type: 'trend_leader',
            data_content: result.data,
          }, { onConflict: 'data_type' });
        
        return {
          data: result.data,
          source: 'akshare',
          updateTime: new Date().toISOString()
        };
      }
    } catch (error) {
      console.error('AKSHARE趋势龙头数据获取失败:', error.message);
    }
    
    // 尝试从缓存获取
    const { data: cache } = await client
      .from('stock_cache')
      .select('*')
      .eq('data_type', 'trend_leader')
      .single();

    if (cache && cache.data_content && cache.data_content.length > 0) {
      console.log('使用缓存趋势龙头数据');
      return {
        data: cache.data_content,
        source: 'cache',
        updateTime: cache.updated_at
      };
    }
    
    // 使用模拟数据
    console.log('使用模拟趋势龙头数据');
    const mockData = this.getMockTrendLeaderData();
    
    return {
      data: mockData,
      source: 'mock',
      updateTime: new Date().toISOString()
    };
  }

  // 模拟龙虎榜数据
  private getMockDragonTigerData() {
    return [
      {
        code: '002466',
        name: '天齐锂业',
        price: 58.90,
        change_percent: 9.98,
        turnover_rate: 8.56,
        amount: 2568900000,
        net_buy: 356800000,
        buy_reason: '锂电池龙头，机构大买',
        sell_reason: '',
        famous_buyers: ['中信证券西安朱雀大街', '华鑫证券上海分公司'],
        famous_sellers: ['机构专用'],
        buy_amount: 586000000,
        sell_amount: 229200000,
        date: new Date().toISOString().split('T')[0]
      },
      {
        code: '300750',
        name: '宁德时代',
        price: 198.50,
        change_percent: 6.89,
        turnover_rate: 5.23,
        amount: 8965000000,
        net_buy: 1256000000,
        buy_reason: '动力电池龙头，北向资金大买',
        sell_reason: '',
        famous_buyers: ['深股通专用', '机构专用'],
        famous_sellers: ['机构专用'],
        buy_amount: 2896000000,
        sell_amount: 1640000000,
        date: new Date().toISOString().split('T')[0]
      },
      {
        code: '002594',
        name: '比亚迪',
        price: 256.80,
        change_percent: 5.45,
        turnover_rate: 3.12,
        amount: 6895000000,
        net_buy: 856000000,
        buy_reason: '新能源龙头，机构加仓',
        sell_reason: '',
        famous_buyers: ['机构专用', '深股通专用'],
        famous_sellers: ['机构专用'],
        buy_amount: 2156000000,
        sell_amount: 1300000000,
        date: new Date().toISOString().split('T')[0]
      },
      {
        code: '601012',
        name: '隆基绿能',
        price: 38.60,
        change_percent: 9.98,
        turnover_rate: 6.78,
        amount: 3568900000,
        net_buy: 456000000,
        buy_reason: '光伏龙头，游资接力',
        sell_reason: '机构减仓',
        famous_buyers: ['财通证券杭州体育场路', '银河证券绍兴营业部'],
        famous_sellers: ['机构专用'],
        buy_amount: 1256000000,
        sell_amount: 800000000,
        date: new Date().toISOString().split('T')[0]
      },
      {
        code: '300033',
        name: '同花顺',
        price: 85.60,
        change_percent: 5.68,
        turnover_rate: 4.56,
        amount: 1256900000,
        net_buy: 289000000,
        buy_reason: '金融科技，量化资金',
        sell_reason: '',
        famous_buyers: ['华泰证券总部', '中金公司上海分公司'],
        famous_sellers: ['机构专用'],
        buy_amount: 568000000,
        sell_amount: 279000000,
        date: new Date().toISOString().split('T')[0]
      },
      {
        code: '002415',
        name: '海康威视',
        price: 32.50,
        change_percent: 4.56,
        turnover_rate: 2.35,
        amount: 1896500000,
        net_buy: 156000000,
        buy_reason: 'AI安防龙头，机构关注',
        sell_reason: '',
        famous_buyers: ['机构专用', '沪股通专用'],
        famous_sellers: ['机构专用'],
        buy_amount: 489000000,
        sell_amount: 333000000,
        date: new Date().toISOString().split('T')[0]
      }
    ];
  }

  // 模拟趋势龙头数据
  private getMockTrendLeaderData() {
    return [
      {
        code: '002466',
        name: '天齐锂业',
        price: 58.90,
        change_percent: 9.98,
        days_rising: 5,
        total_change: 32.56,
        industry: '小金属',
        market_cap: 86500000000,
        turnover_rate: 8.56,
        strength_score: 95,
        trend_stage: '加速上涨',
        support_level: 45.80,
        resistance_level: 65.00
      },
      {
        code: '300750',
        name: '宁德时代',
        price: 198.50,
        change_percent: 6.89,
        days_rising: 4,
        total_change: 18.65,
        industry: '电池',
        market_cap: 435600000000,
        turnover_rate: 5.23,
        strength_score: 88,
        trend_stage: '强势整理',
        support_level: 180.00,
        resistance_level: 220.00
      },
      {
        code: '601012',
        name: '隆基绿能',
        price: 38.60,
        change_percent: 9.98,
        days_rising: 3,
        total_change: 25.68,
        industry: '光伏设备',
        market_cap: 292000000000,
        turnover_rate: 6.78,
        strength_score: 92,
        trend_stage: '突破新高',
        support_level: 32.00,
        resistance_level: 45.00
      },
      {
        code: '002594',
        name: '比亚迪',
        price: 256.80,
        change_percent: 5.45,
        days_rising: 6,
        total_change: 28.90,
        industry: '汽车整车',
        market_cap: 745000000000,
        turnover_rate: 3.12,
        strength_score: 86,
        trend_stage: '趋势加速',
        support_level: 230.00,
        resistance_level: 280.00
      },
      {
        code: '600519',
        name: '贵州茅台',
        price: 1856.50,
        change_percent: 3.25,
        days_rising: 3,
        total_change: 8.56,
        industry: '白酒',
        market_cap: 2330000000000,
        turnover_rate: 0.35,
        strength_score: 78,
        trend_stage: '震荡上行',
        support_level: 1750.00,
        resistance_level: 1950.00
      },
      {
        code: '300033',
        name: '同花顺',
        price: 85.60,
        change_percent: 5.68,
        days_rising: 4,
        total_change: 15.23,
        industry: '计算机应用',
        market_cap: 46000000000,
        turnover_rate: 4.56,
        strength_score: 82,
        trend_stage: '突破整理',
        support_level: 75.00,
        resistance_level: 95.00
      }
    ];
  }

  // 获取新闻催化数据
  async getNewsCatalystData() {
    const client = getSupabaseClient();
    
    // 尝试从AKSHARE获取真实数据
    try {
      console.log('尝试从AKSHARE获取新闻催化数据...');
      const { stdout, stderr } = await execAsync('python3 server/scripts/akshare_data.py news_catalyst', {
        timeout: 30000,
      });
      
      if (stderr) {
        console.error('Python stderr:', stderr);
      }
      
      const result = JSON.parse(stdout);
      
      if (result.code === 200 && result.data && result.data.length > 0) {
        console.log('成功获取新闻催化数据:', result.data.length, '条');
        
        // 更新缓存
        await client
          .from('stock_cache')
          .upsert({
            data_type: 'news_catalyst',
            data_content: result.data,
          }, { onConflict: 'data_type' });
        
        return {
          data: result.data,
          source: 'akshare',
          updateTime: new Date().toISOString()
        };
      }
    } catch (error) {
      console.error('AKSHARE新闻催化数据获取失败:', error.message);
    }
    
    // 尝试从缓存获取
    const { data: cache } = await client
      .from('stock_cache')
      .select('*')
      .eq('data_type', 'news_catalyst')
      .single();

    if (cache && cache.data_content && cache.data_content.length > 0) {
      console.log('使用缓存新闻催化数据');
      return {
        data: cache.data_content,
        source: 'cache',
        updateTime: cache.updated_at
      };
    }
    
    // 使用模拟数据
    console.log('使用模拟新闻催化数据');
    const mockData = this.getMockNewsCatalystData();
    
    return {
      data: mockData,
      source: 'mock',
      updateTime: new Date().toISOString()
    };
  }

  // 模拟新闻催化数据
  private getMockNewsCatalystData() {
    const today = new Date().toISOString().split('T')[0];
    const now = new Date();
    const formatTime = (hours: number) => {
      const d = new Date(now.getTime() - hours * 3600000);
      return `${d.getHours().toString().padStart(2, '0')}:${d.getMinutes().toString().padStart(2, '0')}`;
    };

    return [
      {
        type: '财经新闻',
        title: '锂电池板块持续走强，多股涨停',
        content: '受新能源汽车销量大增影响，锂电池产业链持续火热，天齐锂业、赣锋锂业等多只个股涨停。机构分析认为，随着新能源汽车渗透率不断提升，锂电池需求将持续增长。',
        stocks: ['天齐锂业', '赣锋锂业', '宁德时代'],
        stock_codes: ['002466', '002460', '300750'],
        importance: 'high',
        source: '东方财富',
        publish_time: formatTime(1),
        suggestion: '锂电池板块今日强势，建议关注龙头股的持续性，注意追高风险，可考虑低位补涨股。'
      },
      {
        type: '概念热点',
        title: 'AI概念板块涨幅5.2%，板块热度攀升',
        content: 'AI人工智能概念今日表现强势，板块涨幅超过5%，多只个股涨停。市场预期AI应用落地加速，相关概念股持续受到资金关注。',
        stocks: ['科大讯飞', '海康威视', '同花顺'],
        stock_codes: ['002230', '002415', '300033'],
        importance: 'high',
        source: '同花顺',
        publish_time: formatTime(2),
        suggestion: 'AI概念今日强势，建议关注板块龙头股和低位补涨机会，注意追高风险。'
      },
      {
        type: '热门个股',
        title: '宁德时代 热度飙升',
        content: '股票代码: 300750, 当前价格: 198.50, 涨跌幅: 6.89%',
        stocks: ['宁德时代'],
        stock_codes: ['300750'],
        importance: 'high',
        source: '东方财富',
        publish_time: formatTime(0.5),
        suggestion: '该股当前热度较高，涨幅6.89%，建议关注成交量变化和板块联动效应。'
      },
      {
        type: '财经新闻',
        title: '光伏板块迎政策利好，龙头股大涨',
        content: '国家能源局发布新能源发展规划，光伏板块迎来政策利好，隆基绿能、阳光电源等龙头股大幅上涨，板块整体走强。',
        stocks: ['隆基绿能', '阳光电源', '晶澳科技'],
        stock_codes: ['601012', '300274', '002459'],
        importance: 'high',
        source: '证券时报',
        publish_time: formatTime(3),
        suggestion: '光伏板块受政策利好刺激，建议关注龙头股的持续性，可考虑逢低布局。'
      },
      {
        type: '概念热点',
        title: '新能源汽车概念涨幅4.5%',
        content: '新能源汽车概念今日表现强势，板块涨幅超过4%，比亚迪、小康股份等多只个股涨停。市场预期新能源汽车销量将持续增长。',
        stocks: ['比亚迪', '小康股份', '广汽集团'],
        stock_codes: ['002594', '601127', '601238'],
        importance: 'high',
        source: '东方财富',
        publish_time: formatTime(1.5),
        suggestion: '新能源汽车概念今日强势，建议关注板块龙头股，注意追高风险。'
      },
      {
        type: '财经新闻',
        title: '白酒板块震荡上行，茅台再创新高',
        content: '白酒板块今日震荡上行，贵州茅台股价再创历史新高，五粮液、泸州老窖跟随上涨。机构分析认为，白酒板块估值修复行情持续。',
        stocks: ['贵州茅台', '五粮液', '泸州老窖'],
        stock_codes: ['600519', '000858', '000568'],
        importance: 'medium',
        source: '财经网',
        publish_time: formatTime(4),
        suggestion: '白酒板块估值修复持续，建议关注龙头股的配置价值，注意短期回调风险。'
      },
      {
        type: '热门个股',
        title: '天齐锂业 热度飙升',
        content: '股票代码: 002466, 当前价格: 58.90, 涨跌幅: 9.98%',
        stocks: ['天齐锂业'],
        stock_codes: ['002466'],
        importance: 'high',
        source: '东方财富',
        publish_time: formatTime(0.5),
        suggestion: '该股当前热度较高，涨幅9.98%，建议关注成交量变化和板块联动效应。'
      },
      {
        type: '财经新闻',
        title: '半导体板块受关注，国产替代加速',
        content: '半导体板块今日受资金关注，多只个股上涨。市场预期国产替代进程加速，半导体设备、材料等细分领域有望受益。',
        stocks: ['北方华创', '韦尔股份', '兆易创新'],
        stock_codes: ['002371', '603501', '603986'],
        importance: 'medium',
        source: '中证网',
        publish_time: formatTime(5),
        suggestion: '半导体国产替代长期逻辑不变，建议关注核心标的，注意市场波动风险。'
      },
      {
        type: '概念热点',
        title: '储能概念涨幅3.8%',
        content: '储能概念今日表现强势，板块涨幅近4%，多只个股涨停。市场预期储能市场将迎来快速增长期。',
        stocks: ['阳光电源', '比亚迪', '宁德时代'],
        stock_codes: ['300274', '002594', '300750'],
        importance: 'medium',
        source: '东方财富',
        publish_time: formatTime(2.5),
        suggestion: '储能概念持续火热，建议关注龙头股的持续性，注意追高风险。'
      },
      {
        type: '财经新闻',
        title: '银行板块稳步上涨，估值修复延续',
        content: '银行板块今日稳步上涨，招商银行、兴业银行等龙头股表现强势。机构分析认为，银行板块估值处于历史低位，估值修复行情有望延续。',
        stocks: ['招商银行', '兴业银行', '平安银行'],
        stock_codes: ['600036', '601166', '000001'],
        importance: 'low',
        source: '证券时报',
        publish_time: formatTime(6),
        suggestion: '银行板块估值修复持续，建议关注业绩稳健的龙头股，可考虑中长期配置。'
      }
    ];
  }

  // 获取热点复盘数据
  async getHotReviewData() {
    const client = getSupabaseClient();
    
    // 尝试从AKSHARE获取热点数据
    try {
      console.log('尝试获取热点复盘数据...');
      const { stdout, stderr } = await execAsync('python3 server/scripts/akshare_data.py hot_review', {
        timeout: 30000,
      });
      
      if (stderr) {
        console.error('Python stderr:', stderr);
      }
      
      const result = JSON.parse(stdout);
      
      if (result.code === 200 && result.data) {
        console.log('成功获取热点复盘数据');
        
        // 使用 LLM 进行深度分析
        const analysisResult = await this.analyzeHotDataWithLLM(result.data);
        
        // 更新缓存
        await client
          .from('stock_cache')
          .upsert({
            data_type: 'hot_review',
            data_content: analysisResult,
          }, { onConflict: 'data_type' });
        
        return {
          data: analysisResult,
          source: 'akshare',
          updateTime: new Date().toISOString()
        };
      }
    } catch (error) {
      console.error('热点复盘数据获取失败:', error.message);
    }
    
    // 尝试从缓存获取
    const { data: cache } = await client
      .from('stock_cache')
      .select('*')
      .eq('data_type', 'hot_review')
      .single();

    if (cache && cache.data_content) {
      console.log('使用缓存热点复盘数据');
      return {
        data: cache.data_content,
        source: 'cache',
        updateTime: cache.updated_at
      };
    }
    
    // 使用模拟数据
    console.log('使用模拟热点复盘数据');
    const mockData = await this.getMockHotReviewData();
    
    return {
      data: mockData,
      source: 'mock',
      updateTime: new Date().toISOString()
    };
  }

  // 使用 LLM 分析热点数据
  private async analyzeHotDataWithLLM(rawData: any) {
    try {
      const { LLMClient, Config } = await import('coze-coding-dev-sdk');
      
      const config = new Config();
      const llmClient = new LLMClient(config);
      
      const prompt = `你是一位专业的A股市场分析师。请分析以下今日市场热点数据，并给出专业分析：

今日涨停个股：
${JSON.stringify(rawData.limit_up_stocks || [], null, 2)}

今日热点新闻：
${JSON.stringify(rawData.hot_news || [], null, 2)}

龙虎榜数据：
${JSON.stringify(rawData.dragon_tiger || [], null, 2)}

请完成以下分析任务：
1. 总结今日市场整体情况（100字以内）
2. 分析热门股票的热度原因和投资建议
3. 给出明日市场展望

请以JSON格式返回，格式如下：
{
  "summary": "市场概述",
  "analysis": "详细分析",
  "hot_stocks": [
    {
      "code": "股票代码",
      "name": "股票名称",
      "price": 价格,
      "change_percent": 涨跌幅,
      "heat_score": 热度分数(0-100),
      "heat_sources": ["热度来源"],
      "reasons": ["热门原因"],
      "suggestion": "投资建议",
      "risk_level": "high/medium/low",
      "market_sentiment": "市场情绪",
      "related_concepts": ["相关概念"]
    }
  ]
}`;

      const response = await llmClient.invoke([
        { role: 'system', content: '你是一位专业的A股市场分析师，擅长热点分析和投资建议。' },
        { role: 'user', content: prompt }
      ], { temperature: 0.7 });
      
      // 尝试解析 LLM 返回的 JSON
      try {
        const jsonMatch = response.content.match(/\{[\s\S]*\}/);
        if (jsonMatch) {
          return JSON.parse(jsonMatch[0]);
        }
      } catch (parseError) {
        console.error('解析LLM响应失败:', parseError);
      }
      
      // 如果解析失败，返回原始数据
      return rawData;
    } catch (error) {
      console.error('LLM分析失败:', error);
      return rawData;
    }
  }

  // 模拟热点复盘数据
  private async getMockHotReviewData() {
    const today = new Date();
    const dateStr = today.toISOString().split('T')[0];
    
    return {
      date: dateStr,
      summary: '今日A股市场整体呈现震荡上行态势，锂电池、光伏、新能源汽车等新能源板块表现强势，多只个股涨停。AI概念板块继续活跃，白酒板块估值修复延续。两市成交额突破万亿，市场情绪整体偏乐观。',
      hot_stocks: [
        {
          code: '002466',
          name: '天齐锂业',
          price: 58.90,
          change_percent: 9.98,
          heat_score: 98,
          heat_rank: 1,
          heat_sources: ['东方财富热股榜', '同花顺热门', '雪球热股'],
          reasons: ['锂电池龙头', '新能源概念', '机构大买', '龙虎榜净买入'],
          suggestion: '该股为锂电池龙头，今日强势涨停，市场热度极高。建议关注明日开盘表现，若高开过多需注意追高风险，可考虑回调后介入。支撑位参考54元，压力位在65元附近。',
          risk_level: 'high',
          market_sentiment: '极度活跃',
          related_concepts: ['锂电池', '新能源汽车', '小金属']
        },
        {
          code: '300750',
          name: '宁德时代',
          price: 198.50,
          change_percent: 6.89,
          heat_score: 95,
          heat_rank: 2,
          heat_sources: ['东方财富热股榜', '北向资金流入', '机构调研'],
          reasons: ['动力电池龙头', '北向资金大买', '业绩超预期', '储能概念'],
          suggestion: '宁德时代为动力电池绝对龙头，北向资金持续流入，中长期看好。短期涨幅较大，建议逢回调布局，注意关注180元支撑位。',
          risk_level: 'medium',
          market_sentiment: '活跃',
          related_concepts: ['动力电池', '储能', '新能源汽车']
        },
        {
          code: '002594',
          name: '比亚迪',
          price: 256.80,
          change_percent: 5.45,
          heat_score: 92,
          heat_rank: 3,
          heat_sources: ['同花顺热门', '机构关注', '销量数据'],
          reasons: ['新能源汽车龙头', '销量创新高', '海外市场扩张', '智能化概念'],
          suggestion: '比亚迪为新能源汽车龙头，销量持续超预期，中长期价值明确。当前价格处于上升通道，建议关注230元支撑，逢低可考虑加仓。',
          risk_level: 'medium',
          market_sentiment: '活跃',
          related_concepts: ['新能源汽车', '智能驾驶', '动力电池']
        },
        {
          code: '601012',
          name: '隆基绿能',
          price: 38.60,
          change_percent: 9.98,
          heat_score: 90,
          heat_rank: 4,
          heat_sources: ['光伏板块热股', '政策利好', '龙虎榜'],
          reasons: ['光伏龙头', '政策利好', '碳中和概念', '游资接力'],
          suggestion: '隆基绿能为光伏组件龙头，受政策利好刺激涨停。光伏行业景气度高，但需注意短期涨幅过大风险，建议回调后再介入。支撑位参考32元。',
          risk_level: 'high',
          market_sentiment: '极度活跃',
          related_concepts: ['光伏', '碳中和', '新能源']
        },
        {
          code: '600519',
          name: '贵州茅台',
          price: 1856.50,
          change_percent: 3.25,
          heat_score: 85,
          heat_rank: 5,
          heat_sources: ['北向资金', '机构持仓', '消费龙头'],
          reasons: ['白酒龙头', '估值修复', '北向资金回流', '消费复苏'],
          suggestion: '茅台为A股价值投资标杆，估值处于合理区间，北向资金持续回流。适合中长期配置，短期关注1750元支撑和1950元压力位。',
          risk_level: 'low',
          market_sentiment: '稳定',
          related_concepts: ['白酒', '消费', '价值投资']
        },
        {
          code: '300033',
          name: '同花顺',
          price: 85.60,
          change_percent: 5.68,
          heat_score: 82,
          heat_rank: 6,
          heat_sources: ['AI概念', '金融科技', '量化资金'],
          reasons: ['金融科技龙头', 'AI概念', '行情活跃受益', '量化资金关注'],
          suggestion: '同花顺受益于市场行情活跃和AI概念，短期走势较强。建议关注AI板块整体表现，注意追高风险，支撑位参考75元。',
          risk_level: 'medium',
          market_sentiment: '活跃',
          related_concepts: ['金融科技', 'AI', '大数据']
        }
      ],
      top_news: [
        { title: '锂电池板块持续走强，多股涨停', source: '东方财富', time: '10:30' },
        { title: '新能源车销量创新高，产业链受益', source: '证券时报', time: '11:00' },
        { title: '北向资金净流入超百亿', source: '同花顺', time: '14:00' },
        { title: '光伏政策利好落地，龙头股大涨', source: '中证网', time: '14:30' },
        { title: 'AI概念持续活跃，多股涨停', source: '财经网', time: '15:00' }
      ],
      analysis: `【市场分析】

今日A股市场整体呈现强势格局，新能源板块成为市场主线，锂电池、光伏、新能源汽车等细分领域表现亮眼。

【资金面分析】
- 北向资金净流入超百亿，主要流入新能源、消费板块
- 两市成交额突破万亿，市场活跃度提升
- 龙虎榜显示机构资金积极布局新能源龙头

【板块轮动】
- 早盘：锂电池板块率先启动，天齐锂业快速涨停
- 午盘：光伏板块受政策利好刺激，隆基绿能涨停
- 尾盘：AI概念活跃，同花顺等科技股走强

【明日展望】
1. 新能源板块热度有望延续，但需注意分化风险
2. 建议关注低位补涨机会，避免追高
3. 北向资金动向仍需密切关注
4. 短期关注成交量变化，若持续放量则行情有望延续

【风险提示】
- 部分热点股短期涨幅较大，注意回调风险
- 市场情绪过热时需保持理性
- 建议控制仓位，做好风险管理`
    };
  }
}
