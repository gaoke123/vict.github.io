#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
AKSHARE 行业板块数据获取脚本
获取A股行业板块实时数据，包括板块名称、涨幅、涨速、领涨股等
"""

import sys
import json
import time
import akshare as ak

def get_industry_board():
    """获取行业板块数据"""
    try:
        print("开始获取行业板块数据...", file=sys.stderr)
        
        # 方法1: 使用东方财富行业板块接口
        try:
            print("尝试方法1: stock_board_industry_name_em", file=sys.stderr)
            df = ak.stock_board_industry_name_em()
            print(f"获取到 {len(df)} 个板块", file=sys.stderr)
            
            result = []
            for idx, row in df.head(30).iterrows():  # 限制只处理前30个板块
                try:
                    symbol = row['板块名称']
                    print(f"处理板块: {symbol}", file=sys.stderr)
                    
                    # 获取板块指数数据
                    try:
                        board_df = ak.stock_board_industry_index_em(symbol=symbol)
                        if board_df is not None and len(board_df) > 0:
                            latest = board_df.iloc[-1]
                            change_percent = float(latest.get('涨跌幅', 0)) if '涨跌幅' in latest else 0
                            change_speed = float(latest.get('涨速', 0)) if '涨速' in latest else 0
                            latest_price = float(latest.get('最新价', 0)) if '最新价' in latest else 0
                            turnover_rate = float(latest.get('换手率', 0)) if '换手率' in latest else 0
                            amount = float(latest.get('成交额', 0)) if '成交额' in latest else 0
                            up_count = int(latest.get('上涨家数', 0)) if '上涨家数' in latest else 0
                            down_count = int(latest.get('下跌家数', 0)) if '下跌家数' in latest else 0
                        else:
                            change_percent = 0
                            change_speed = 0
                            latest_price = 0
                            turnover_rate = 0
                            amount = 0
                            up_count = 0
                            down_count = 0
                    except Exception as e:
                        print(f"获取板块指数失败: {e}", file=sys.stderr)
                        change_percent = 0
                        change_speed = 0
                        latest_price = 0
                        turnover_rate = 0
                        amount = 0
                        up_count = 0
                        down_count = 0
                    
                    # 获取领涨股
                    top_stocks = []
                    try:
                        cons_df = ak.stock_board_industry_cons_em(symbol=symbol)
                        if cons_df is not None and len(cons_df) > 0:
                            # 按涨幅排序
                            cons_df = cons_df.sort_values(by='涨跌幅', ascending=False)
                            for _, stock in cons_df.head(3).iterrows():
                                top_stocks.append({
                                    '代码': str(stock.get('代码', '')),
                                    '名称': str(stock.get('名称', '')),
                                    '最新价': float(stock.get('最新价', 0)) if stock.get('最新价') else 0,
                                    '涨跌幅': float(stock.get('涨跌幅', 0)) if stock.get('涨跌幅') else 0,
                                    '涨速': float(stock.get('涨速', 0)) if stock.get('涨速') else 0
                                })
                    except Exception as e:
                        print(f"获取领涨股失败: {e}", file=sys.stderr)
                    
                    item = {
                        'board_name': symbol,
                        'board_code': row.get('板块代码', ''),
                        'change_percent': change_percent,
                        'change_speed': change_speed,
                        'latest_price': latest_price,
                        'turnover_rate': turnover_rate,
                        'amount': amount,
                        'top_stocks': top_stocks,
                        'up_count': up_count,
                        'down_count': down_count,
                    }
                    result.append(item)
                    time.sleep(0.1)  # 避免请求过快
                    
                except Exception as e:
                    print(f"处理板块 {symbol} 失败: {e}", file=sys.stderr)
                    continue
            
            if result:
                # 按涨幅排序
                result.sort(key=lambda x: x['change_percent'], reverse=True)
                return json.dumps({
                    'code': 200,
                    'msg': 'success',
                    'data': result
                }, ensure_ascii=False)
                
        except Exception as e:
            print(f"方法1失败: {e}", file=sys.stderr)
        
        # 方法2: 使用新浪行业板块接口
        print("尝试方法2: 新浪行业板块", file=sys.stderr)
        try:
            df = ak.stock_board_industry_name_sina()
            if df is not None and len(df) > 0:
                result = []
                for _, row in df.iterrows():
                    item = {
                        'board_name': str(row.get('板块名称', '')),
                        'board_code': '',
                        'change_percent': float(row.get('涨跌幅', 0)) if row.get('涨跌幅') else 0,
                        'change_speed': 0,
                        'latest_price': float(row.get('最新价', 0)) if row.get('最新价') else 0,
                        'turnover_rate': 0,
                        'amount': 0,
                        'top_stocks': [],
                        'up_count': 0,
                        'down_count': 0,
                    }
                    result.append(item)
                
                result.sort(key=lambda x: x['change_percent'], reverse=True)
                return json.dumps({
                    'code': 200,
                    'msg': 'success',
                    'data': result[:20]
                }, ensure_ascii=False)
        except Exception as e:
            print(f"方法2失败: {e}", file=sys.stderr)
        
        # 如果都失败，返回错误
        return json.dumps({
            'code': 500,
            'msg': '无法获取行业板块数据，请稍后重试',
            'data': None
        }, ensure_ascii=False)
        
    except Exception as e:
        print(f"获取行业板块数据异常: {e}", file=sys.stderr)
        return json.dumps({
            'code': 500,
            'msg': str(e),
            'data': None
        }, ensure_ascii=False)


def get_limit_up_stocks():
    """获取涨停个股数据"""
    try:
        print("开始获取涨停数据...", file=sys.stderr)
        
        # 方法1: 使用东方财富涨停池接口
        try:
            print("尝试获取涨停池数据...", file=sys.stderr)
            df = ak.stock_zt_pool_em(date=None)
            
            result = []
            if df is not None and len(df) > 0:
                for _, row in df.iterrows():
                    item = {
                        'code': str(row.get('代码', '')),
                        'name': str(row.get('名称', '')),
                        'price': float(row.get('最新价', 0)) if row.get('最新价') else 0,
                        'change_percent': float(row.get('涨跌幅', 0)) if row.get('涨跌幅') else 0,
                        'limit_up_time': str(row.get('涨停时间', '')),
                        'first_limit_up_time': str(row.get('首次涨停时间', '')),
                        'open_count': int(row.get('开板次数', 0)) if row.get('开板次数') else 0,
                        'turnover_rate': float(row.get('换手率', 0)) if row.get('换手率') else 0,
                        'amount': float(row.get('成交额', 0)) if row.get('成交额') else 0,
                        'reason': str(row.get('涨停原因类别', '')),
                    }
                    result.append(item)
            
            if result:
                return json.dumps({
                    'code': 200,
                    'msg': 'success',
                    'data': result
                }, ensure_ascii=False)
                
        except Exception as e:
            print(f"涨停池接口失败: {e}", file=sys.stderr)
        
        # 方法2: 使用涨停股池统计
        try:
            print("尝试涨停股池统计...", file=sys.stderr)
            df = ak.stock_zt_pool_zbgc_em(date=None)
            
            result = []
            if df is not None and len(df) > 0:
                for _, row in df.iterrows():
                    item = {
                        'code': str(row.get('代码', '')),
                        'name': str(row.get('名称', '')),
                        'price': float(row.get('最新价', 0)) if row.get('最新价') else 0,
                        'change_percent': 9.99,  # 涨停
                        'limit_up_time': str(row.get('涨停时间', '')),
                        'first_limit_up_time': '',
                        'open_count': 0,
                        'turnover_rate': 0,
                        'amount': 0,
                        'reason': '',
                    }
                    result.append(item)
            
            if result:
                return json.dumps({
                    'code': 200,
                    'msg': 'success',
                    'data': result
                }, ensure_ascii=False)
                
        except Exception as e:
            print(f"涨停股池统计失败: {e}", file=sys.stderr)
        
        return json.dumps({
            'code': 500,
            'msg': '无法获取涨停数据，请稍后重试',
            'data': None
        }, ensure_ascii=False)
        
    except Exception as e:
        print(f"获取涨停数据异常: {e}", file=sys.stderr)
        return json.dumps({
            'code': 500,
            'msg': str(e),
            'data': None
        }, ensure_ascii=False)


if __name__ == '__main__':
    if len(sys.argv) < 2:
        print(json.dumps({'code': 400, 'msg': '缺少参数', 'data': None}, ensure_ascii=False))
        sys.exit(1)
    
    action = sys.argv[1]
    
    if action == 'industry':
        print(get_industry_board())
    elif action == 'limit_up':
        print(get_limit_up_stocks())
def get_dragon_tiger():
    """获取龙虎榜数据"""
    try:
        print("开始获取龙虎榜数据...", file=sys.stderr)
        
        # 方法1: 使用东方财富龙虎榜接口
        try:
            print("尝试获取龙虎榜数据...", file=sys.stderr)
            df = ak.stock_lhb_detail_em(start_date=None, end_date=None)
            
            result = []
            if df is not None and len(df) > 0:
                seen_codes = set()
                for _, row in df.iterrows():
                    code = str(row.get('代码', ''))
                    if code in seen_codes:
                        continue
                    seen_codes.add(code)
                    
                    item = {
                        'code': code,
                        'name': str(row.get('名称', '')),
                        'price': float(row.get('收盘价', 0)) if row.get('收盘价') else 0,
                        'change_percent': float(row.get('涨跌幅', 0)) if row.get('涨跌幅') else 0,
                        'turnover_rate': float(row.get('换手率', 0)) if row.get('换手率') else 0,
                        'amount': float(row.get('总成交额', 0)) if row.get('总成交额') else 0,
                        'net_buy': float(row.get('净买入', 0)) if row.get('净买入') else 0,
                        'buy_reason': str(row.get('上榜原因', '')),
                        'sell_reason': '',
                        'famous_buyers': [],
                        'famous_sellers': [],
                        'buy_amount': float(row.get('买入金额', 0)) if row.get('买入金额') else 0,
                        'sell_amount': float(row.get('卖出金额', 0)) if row.get('卖出金额') else 0,
                        'date': str(row.get('日期', '')),
                    }
                    result.append(item)
                    
                    if len(result) >= 20:  # 限制返回20条
                        break
            
            if result:
                return json.dumps({
                    'code': 200,
                    'msg': 'success',
                    'data': result
                }, ensure_ascii=False)
                
        except Exception as e:
            print(f"龙虎榜接口失败: {e}", file=sys.stderr)
        
        # 方法2: 使用龙虎榜统计
        try:
            print("尝试龙虎榜统计...", file=sys.stderr)
            df = ak.stock_lhb_stock_statistic_em(symbol='近3日上榜')
            
            result = []
            if df is not None and len(df) > 0:
                for _, row in df.iterrows():
                    item = {
                        'code': str(row.get('代码', '')),
                        'name': str(row.get('名称', '')),
                        'price': float(row.get('最新价', 0)) if row.get('最新价') else 0,
                        'change_percent': float(row.get('涨跌幅', 0)) if row.get('涨跌幅') else 0,
                        'turnover_rate': 0,
                        'amount': 0,
                        'net_buy': float(row.get('龙虎榜净买额', 0)) if row.get('龙虎榜净买额') else 0,
                        'buy_reason': str(row.get('上榜原因', '')),
                        'sell_reason': '',
                        'famous_buyers': [],
                        'famous_sellers': [],
                        'buy_amount': float(row.get('龙虎榜买入额', 0)) if row.get('龙虎榜买入额') else 0,
                        'sell_amount': float(row.get('龙虎榜卖出额', 0)) if row.get('龙虎榜卖出额') else 0,
                        'date': '',
                    }
                    result.append(item)
            
            if result:
                return json.dumps({
                    'code': 200,
                    'msg': 'success',
                    'data': result[:20]
                }, ensure_ascii=False)
                
        except Exception as e:
            print(f"龙虎榜统计失败: {e}", file=sys.stderr)
        
        return json.dumps({
            'code': 500,
            'msg': '无法获取龙虎榜数据，请稍后重试',
            'data': None
        }, ensure_ascii=False)
        
    except Exception as e:
        print(f"获取龙虎榜数据异常: {e}", file=sys.stderr)
        return json.dumps({
            'code': 500,
            'msg': str(e),
            'data': None
        }, ensure_ascii=False)


def get_trend_leader():
    """获取趋势龙头数据"""
    try:
        print("开始获取趋势龙头数据...", file=sys.stderr)
        
        # 方法1: 使用连涨股接口
        try:
            print("尝试获取连涨股数据...", file=sys.stderr)
            df = ak.stock_zt_pool_zbgc_em(date=None)
            
            result = []
            if df is not None and len(df) > 0:
                for _, row in df.iterrows():
                    change_percent = float(row.get('涨跌幅', 0)) if row.get('涨跌幅') else 0
                    days_rising = int(row.get('连续涨停天数', 0)) if row.get('连续涨停天数') else 0
                    
                    if days_rising < 2:  # 只关注连续涨停2天以上的
                        continue
                    
                    item = {
                        'code': str(row.get('代码', '')),
                        'name': str(row.get('名称', '')),
                        'price': float(row.get('最新价', 0)) if row.get('最新价') else 0,
                        'change_percent': change_percent,
                        'days_rising': days_rising,
                        'total_change': change_percent * days_rising,  # 估算
                        'industry': str(row.get('所属行业', '')),
                        'market_cap': 0,
                        'turnover_rate': float(row.get('换手率', 0)) if row.get('换手率') else 0,
                        'strength_score': min(95, 70 + days_rising * 5),
                        'trend_stage': '加速上涨' if days_rising >= 3 else '趋势启动',
                        'support_level': float(row.get('最新价', 0)) * 0.9 if row.get('最新价') else 0,
                        'resistance_level': float(row.get('最新价', 0)) * 1.1 if row.get('最新价') else 0,
                    }
                    result.append(item)
            
            if result:
                # 按连涨天数排序
                result.sort(key=lambda x: x['days_rising'], reverse=True)
                return json.dumps({
                    'code': 200,
                    'msg': 'success',
                    'data': result[:20]
                }, ensure_ascii=False)
                
        except Exception as e:
            print(f"连涨股接口失败: {e}", file=sys.stderr)
        
        # 方法2: 使用强势股接口
        try:
            print("尝试获取强势股数据...", file=sys.stderr)
            df = ak.stock_zh_a_spot_em()
            
            result = []
            if df is not None and len(df) > 0:
                # 筛选涨幅前50的股票
                df_sorted = df.sort_values(by='涨跌幅', ascending=False).head(50)
                
                for _, row in df_sorted.iterrows():
                    change_percent = float(row.get('涨跌幅', 0)) if row.get('涨跌幅') else 0
                    if change_percent < 3:  # 只关注涨幅3%以上的
                        continue
                    
                    item = {
                        'code': str(row.get('代码', '')),
                        'name': str(row.get('名称', '')),
                        'price': float(row.get('最新价', 0)) if row.get('最新价') else 0,
                        'change_percent': change_percent,
                        'days_rising': 1,  # 默认1天
                        'total_change': change_percent,
                        'industry': str(row.get('所属行业', '')),
                        'market_cap': float(row.get('总市值', 0)) if row.get('总市值') else 0,
                        'turnover_rate': float(row.get('换手率', 0)) if row.get('换手率') else 0,
                        'strength_score': min(95, 60 + change_percent),
                        'trend_stage': '突破上涨',
                        'support_level': float(row.get('今开', 0)) if row.get('今开') else 0,
                        'resistance_level': float(row.get('最高', 0)) if row.get('最高') else 0,
                    }
                    result.append(item)
            
            if result:
                result.sort(key=lambda x: x['strength_score'], reverse=True)
                return json.dumps({
                    'code': 200,
                    'msg': 'success',
                    'data': result[:20]
                }, ensure_ascii=False)
                
        except Exception as e:
            print(f"强势股接口失败: {e}", file=sys.stderr)
        
        return json.dumps({
            'code': 500,
            'msg': '无法获取趋势龙头数据，请稍后重试',
            'data': None
        }, ensure_ascii=False)
        
    except Exception as e:
        print(f"获取趋势龙头数据异常: {e}", file=sys.stderr)
        return json.dumps({
            'code': 500,
            'msg': str(e),
            'data': None
        }, ensure_ascii=False)


def get_news_catalyst():
    """获取新闻催化数据"""
    try:
        print("开始获取新闻催化数据...", file=sys.stderr)
        
        result = []
        
        # 方法1: 使用东方财富股吧热门
        try:
            print("尝试获取股吧热门...", file=sys.stderr)
            df = ak.stock_zh_a_hot_em(symbol="热门")
            
            if df is not None and len(df) > 0:
                for _, row in df.head(10).iterrows():
                    item = {
                        'type': '热门个股',
                        'title': str(row.get('股票名称', '')) + ' 热度飙升',
                        'content': f"股票代码: {row.get('股票代码', '')}, 当前价格: {row.get('最新价', 0)}, 涨跌幅: {row.get('涨跌幅', 0)}%",
                        'stocks': [str(row.get('股票名称', ''))],
                        'stock_codes': [str(row.get('股票代码', ''))],
                        'importance': 'high' if float(row.get('涨跌幅', 0)) > 5 else 'medium',
                        'source': '东方财富',
                        'publish_time': '',
                        'suggestion': f"该股当前热度较高，涨幅{row.get('涨跌幅', 0)}%，建议关注成交量变化和板块联动效应。"
                    }
                    result.append(item)
        except Exception as e:
            print(f"股吧热门获取失败: {e}", file=sys.stderr)
        
        # 方法2: 使用财经新闻接口
        try:
            print("尝试获取财经新闻...", file=sys.stderr)
            df = ak.stock_news_em(symbol="财经新闻")
            
            if df is not None and len(df) > 0:
                for _, row in df.head(15).iterrows():
                    title = str(row.get('标题', ''))
                    content = str(row.get('内容', ''))
                    
                    # 尝试从标题和内容中提取股票名称
                    import re
                    stock_pattern = r'[\u4e00-\u9fa5]{2,4}(?:股份|集团|科技|电子|医药|银行|证券|保险|汽车|能源|材料)'
                    stocks = re.findall(stock_pattern, title + content)
                    stocks = list(set(stocks))[:3]  # 去重，最多3个
                    
                    # 判断重要性
                    importance = 'medium'
                    if any(keyword in title for keyword in ['涨停', '暴涨', '重大', '利好', '突破']):
                        importance = 'high'
                    elif any(keyword in title for keyword in ['下跌', '利空', '风险']):
                        importance = 'low'
                    
                    # 生成建议
                    suggestion = generate_suggestion(title, content)
                    
                    item = {
                        'type': '财经新闻',
                        'title': title,
                        'content': content[:200] + '...' if len(content) > 200 else content,
                        'stocks': stocks,
                        'stock_codes': [],
                        'importance': importance,
                        'source': str(row.get('来源', '东方财富')),
                        'publish_time': str(row.get('发布时间', '')),
                        'suggestion': suggestion
                    }
                    result.append(item)
        except Exception as e:
            print(f"财经新闻获取失败: {e}", file=sys.stderr)
        
        # 方法3: 使用概念板块新闻
        try:
            print("尝试获取概念板块数据...", file=sys.stderr)
            df = ak.stock_board_concept_name_em()
            
            if df is not None and len(df) > 0:
                # 获取涨幅前5的概念
                df_sorted = df.sort_values(by='涨跌幅', ascending=False).head(5)
                
                for _, row in df_sorted.iterrows():
                    change = float(row.get('涨跌幅', 0))
                    if change < 2:  # 只关注涨幅2%以上的概念
                        continue
                    
                    concept_name = str(row.get('板块名称', ''))
                    item = {
                        'type': '概念热点',
                        'title': f'{concept_name}概念板块涨幅{change:.2f}%',
                        'content': f"概念板块{concept_name}今日表现强势，涨幅达{change:.2f}%，上涨家数{row.get('上涨家数', 0)}家，下跌家数{row.get('下跌家数', 0)}家。",
                        'stocks': [],
                        'stock_codes': [],
                        'importance': 'high' if change > 5 else 'medium',
                        'source': '东方财富',
                        'publish_time': '',
                        'suggestion': f"{concept_name}概念今日强势，建议关注板块龙头股和低位补涨机会，注意追高风险。"
                    }
                    result.append(item)
        except Exception as e:
            print(f"概念板块获取失败: {e}", file=sys.stderr)
        
        if result:
            # 按重要性排序
            importance_order = {'high': 0, 'medium': 1, 'low': 2}
            result.sort(key=lambda x: importance_order.get(x['importance'], 1))
            return json.dumps({
                'code': 200,
                'msg': 'success',
                'data': result[:30]  # 返回前30条
            }, ensure_ascii=False)
        
        return json.dumps({
            'code': 500,
            'msg': '无法获取新闻数据，请稍后重试',
            'data': None
        }, ensure_ascii=False)
        
    except Exception as e:
        print(f"获取新闻数据异常: {e}", file=sys.stderr)
        return json.dumps({
            'code': 500,
            'msg': str(e),
            'data': None
        }, ensure_ascii=False)


def generate_suggestion(title, content):
    """根据新闻内容生成投资建议"""
    text = title + content
    
    # 利好消息
    positive_keywords = ['涨停', '暴涨', '利好', '突破', '新高', '业绩大增', '中标', '签约', '并购', '重组']
    # 利空消息
    negative_keywords = ['下跌', '暴跌', '利空', '亏损', '减持', '质押', '诉讼', '违规', '处罚']
    
    has_positive = any(kw in text for kw in positive_keywords)
    has_negative = any(kw in text for kw in negative_keywords)
    
    if has_positive and not has_negative:
        return "消息面偏利好，建议关注相关个股的持续性，注意追高风险，可考虑逢低布局。"
    elif has_negative and not has_positive:
        return "消息面偏利空，建议谨慎观望，注意风险控制，等待企稳信号。"
    elif has_positive and has_negative:
        return "消息面多空交织，建议综合分析，关注量能变化，谨慎参与。"
    else:
        return "建议关注市场对该消息的反应，观察成交量变化，理性判断投资价值。"


def get_hot_review():
    """获取热点复盘数据"""
    try:
        print("开始获取热点复盘数据...", file=sys.stderr)
        
        result = {
            'limit_up_stocks': [],
            'hot_news': [],
            'dragon_tiger': []
        }
        
        # 获取涨停股数据
        try:
            print("获取涨停股数据...", file=sys.stderr)
            df = ak.stock_zt_pool_em(date=None)
            if df is not None and len(df) > 0:
                for _, row in df.head(20).iterrows():
                    item = {
                        'code': str(row.get('代码', '')),
                        'name': str(row.get('名称', '')),
                        'price': float(row.get('最新价', 0)) if row.get('最新价') else 0,
                        'change_percent': float(row.get('涨跌幅', 0)) if row.get('涨跌幅') else 0,
                        'limit_up_time': str(row.get('涨停时间', '')),
                        'reason': str(row.get('涨停原因类别', '')),
                    }
                    result['limit_up_stocks'].append(item)
        except Exception as e:
            print(f"涨停股获取失败: {e}", file=sys.stderr)
        
        # 获取热门股票
        try:
            print("获取热门股票...", file=sys.stderr)
            df = ak.stock_zh_a_hot_em(symbol="热门")
            if df is not None and len(df) > 0:
                for _, row in df.head(10).iterrows():
                    item = {
                        'code': str(row.get('股票代码', '')),
                        'name': str(row.get('股票名称', '')),
                        'price': float(row.get('最新价', 0)) if row.get('最新价') else 0,
                        'change_percent': float(row.get('涨跌幅', 0)) if row.get('涨跌幅') else 0,
                        'heat_score': 90 - df.head(10).index.tolist().index(_) * 3,  # 热度递减
                    }
                    result['hot_news'].append({
                        'title': f"{row.get('股票名称', '')} 热度排名第{df.head(10).index.tolist().index(_) + 1}",
                        'source': '东方财富',
                        'type': 'hot_stock',
                        'data': item
                    })
        except Exception as e:
            print(f"热门股票获取失败: {e}", file=sys.stderr)
        
        # 获取财经新闻
        try:
            print("获取财经新闻...", file=sys.stderr)
            df = ak.stock_news_em(symbol="财经新闻")
            if df is not None and len(df) > 0:
                for _, row in df.head(10).iterrows():
                    item = {
                        'title': str(row.get('标题', '')),
                        'source': str(row.get('来源', '东方财富')),
                        'time': str(row.get('发布时间', '')),
                        'type': 'news'
                    }
                    result['hot_news'].append(item)
        except Exception as e:
            print(f"财经新闻获取失败: {e}", file=sys.stderr)
        
        # 获取龙虎榜数据
        try:
            print("获取龙虎榜数据...", file=sys.stderr)
            df = ak.stock_lhb_stock_statistic_em(symbol='今日上榜')
            if df is not None and len(df) > 0:
                for _, row in df.head(10).iterrows():
                    item = {
                        'code': str(row.get('代码', '')),
                        'name': str(row.get('名称', '')),
                        'net_buy': float(row.get('龙虎榜净买额', 0)) if row.get('龙虎榜净买额') else 0,
                        'buy_reason': str(row.get('上榜原因', '')),
                    }
                    result['dragon_tiger'].append(item)
        except Exception as e:
            print(f"龙虎榜获取失败: {e}", file=sys.stderr)
        
        if result['limit_up_stocks'] or result['hot_news'] or result['dragon_tiger']:
            return json.dumps({
                'code': 200,
                'msg': 'success',
                'data': result
            }, ensure_ascii=False)
        
        return json.dumps({
            'code': 500,
            'msg': '无法获取热点数据，请稍后重试',
            'data': None
        }, ensure_ascii=False)
        
    except Exception as e:
        print(f"获取热点复盘数据异常: {e}", file=sys.stderr)
        return json.dumps({
            'code': 500,
            'msg': str(e),
            'data': None
        }, ensure_ascii=False)


if __name__ == '__main__':
    if len(sys.argv) < 2:
        print(json.dumps({'code': 400, 'msg': '缺少参数', 'data': None}, ensure_ascii=False))
        sys.exit(1)
    
    action = sys.argv[1]
    
    if action == 'industry':
        print(get_industry_board())
    elif action == 'limit_up':
        print(get_limit_up_stocks())
    elif action == 'dragon_tiger':
        print(get_dragon_tiger())
    elif action == 'trend_leader':
        print(get_trend_leader())
    elif action == 'news_catalyst':
        print(get_news_catalyst())
    elif action == 'hot_review':
        print(get_hot_review())
    else:
        print(json.dumps({'code': 400, 'msg': '无效参数', 'data': None}, ensure_ascii=False))
